#!/usr/bin/env node
const fetch = require('node-fetch');
require('dotenv').config({ path: '.env.local' });

const BASE_URL = 'http://localhost:3002/api';
const TEST_USER_PHONE = '+919876543210';

class APITester {
  constructor() {
    this.results = [];
    this.userToken = '';
    this.colors = {
      reset: '\x1b[0m',
      bright: '\x1b[1m',
      green: '\x1b[32m',
      red: '\x1b[31m',
      yellow: '\x1b[33m',
      cyan: '\x1b[36m',
      blue: '\x1b[34m'
    };
    
    console.log(`${this.colors.cyan}${this.colors.bright}
╔══════════════════════════════════════════╗
║     API ENDPOINT TESTING SUITE           ║
║     True OTP Application                 ║
╚══════════════════════════════════════════╝${this.colors.reset}\n`);
  }

  log(type, message) {
    const colors = {
      info: this.colors.blue,
      success: this.colors.green,
      error: this.colors.red,
      warning: this.colors.yellow
    };
    const icons = {
      info: 'ℹ',
      success: '✓',
      error: '✗',
      warning: '⚠'
    };
    console.log(`${colors[type]}${icons[type]} ${message}${this.colors.reset}`);
  }

  async testEndpoint(endpoint, method, options = {}) {
    const startTime = Date.now();
    const fullUrl = `${BASE_URL}${endpoint}`;
    
    try {
      const response = await fetch(fullUrl, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers
        },
        body: options.body ? JSON.stringify(options.body) : undefined
      });

      const responseTime = Date.now() - startTime;
      const expectedStatus = options.expectedStatus || 200;
      
      const result = {
        endpoint,
        method,
        status: response.status === expectedStatus ? 'PASS' : 'FAIL',
        statusCode: response.status,
        responseTime,
        message: response.status === expectedStatus 
          ? `Response: ${response.status} (${responseTime}ms)`
          : `Expected ${expectedStatus}, got ${response.status}`
      };

      if (result.status === 'PASS') {
        this.log('success', `${method} ${endpoint} - ${result.message}`);
      } else {
        this.log('error', `${method} ${endpoint} - ${result.message}`);
      }

      this.results.push(result);
      return result;
    } catch (error) {
      const result = {
        endpoint,
        method,
        status: 'FAIL',
        message: error.message
      };
      this.log('error', `${method} ${endpoint} - ${error.message}`);
      this.results.push(result);
      return result;
    }
  }

  async runTests() {
    console.log(`${this.colors.bright}Starting API Tests...${this.colors.reset}\n`);

    // Authentication Tests
    console.log(`${this.colors.cyan}${this.colors.bright}━━━ Authentication Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/auth/register-initiate', 'POST', {
      body: { phone: TEST_USER_PHONE },
      expectedStatus: 200
    });

    await this.testEndpoint('/auth/request-qr', 'POST', {
      body: { phone: TEST_USER_PHONE }
    });

    // Public Endpoints
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Public Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/packages', 'GET');
    
    await this.testEndpoint('/contact', 'POST', {
      body: {
        name: 'Test User',
        email: 'test@example.com',
        phone: '+919876543210',
        message: 'Test message'
      }
    });

    // Protected Endpoints (will fail without token)
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Protected User Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/sessions', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/usage', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/transactions', 'GET', {
      expectedStatus: 401
    });

    // Admin Endpoints (require NextAuth session)
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Admin Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/admin/summary', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/users', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/tickets', 'GET', {
      expectedStatus: 401
    });

    this.printSummary();
  }

  printSummary() {
    const passed = this.results.filter(r => r.status === 'PASS').length;
    const failed = this.results.filter(r => r.status === 'FAIL').length;
    const total = this.results.length;
    const avgResponseTime = this.results
      .filter(r => r.responseTime)
      .reduce((acc, r) => acc + (r.responseTime || 0), 0) / 
      this.results.filter(r => r.responseTime).length || 0;

    console.log(`\n${this.colors.cyan}${this.colors.bright}
╔══════════════════════════════════════════╗
║           TEST SUMMARY                   ║
╚══════════════════════════════════════════╝${this.colors.reset}

${this.colors.bright}Total Tests:${this.colors.reset} ${total}
${this.colors.green}✓ Passed:${this.colors.reset} ${passed}
${this.colors.red}✗ Failed:${this.colors.reset} ${failed}
${this.colors.blue}⚡ Avg Response Time:${this.colors.reset} ${avgResponseTime.toFixed(2)}ms

${this.colors.bright}Success Rate:${this.colors.reset} ${((passed / total) * 100).toFixed(1)}%
`);

    if (failed > 0) {
      console.log(`${this.colors.red}${this.colors.bright}Failed Tests:${this.colors.reset}`);
      this.results
        .filter(r => r.status === 'FAIL')
        .forEach(r => {
          console.log(`  ${this.colors.red}✗ ${r.method} ${r.endpoint} - ${r.message}${this.colors.reset}`);
        });
    }
  }
}

const tester = new APITester();
tester.runTests().catch(console.error);
