// Create the target PostgreSQL database if it does not exist
// Usage:
//   DOTENV_CONFIG_PATH=.env.server node -r dotenv/config scripts/create-db.js

const { Client } = require('pg');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

function parseDb(url) {
  const u = new URL(url);
  const dbName = u.pathname.replace(/^\//, '') || 'postgres';
  const adminUrl = new URL(url);
  adminUrl.pathname = '/postgres';
  return { dbName, adminUrl: adminUrl.toString() };
}

(async () => {
  try {
    // Attempt to load env if DATABASE_URL is missing
    if (!process.env.DATABASE_URL) {
      const root = path.join(__dirname, '..');
      const candidates = [
        process.env.DOTENV_CONFIG_PATH,
        path.join(root, 'env.server'),
        path.join(root, '.env.server'),
        path.join(root, '.env.local'),
        path.join(root, '.env'),
      ].filter(Boolean);
      for (const p of candidates) {
        try {
          if (fs.existsSync(p)) {
            dotenv.config({ path: p });
            if (process.env.DATABASE_URL) {
              console.log('[create-db] loaded env from', p);
              break;
            }
          }
        } catch {}
      }
    }

    const url = process.env.DATABASE_URL;
    if (!url) {
      console.error('DATABASE_URL is not set');
      process.exit(1);
    }
    const { dbName, adminUrl } = parseDb(url);

    const admin = new Client({
      connectionString: adminUrl,
      ssl: /sslmode=require|ssl=true/i.test(String(url)) ? { rejectUnauthorized: false } : undefined,
    });
    await admin.connect();

    const existsRes = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
    if (existsRes.rowCount > 0) {
      console.log(`[create-db] Database already exists: ${dbName}`);
    } else {
      await admin.query(`CREATE DATABASE ${JSON.stringify(dbName).replace(/^"|"$/g, '')}`);
      console.log(`[create-db] Created database: ${dbName}`);
    }
    await admin.end();
    process.exit(0);
  } catch (e) {
    console.error('[create-db] Failed:', e?.message || e);
    process.exit(1);
  }
})();
