#!/usr/bin/env node
import fetch from 'node-fetch';
import { config } from 'dotenv';
import { resolve } from 'path';

// Load environment variables
config({ path: resolve(process.cwd(), '.env.local') });

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';
const ADMIN_EMAIL = 'admin@example.com';
const ADMIN_PASSWORD = 'admin123';
const TEST_USER_EMAIL = 'test@example.com';
const TEST_USER_PHONE = '+919876543210';
const TEST_USER_PASSWORD = 'test123';

interface TestResult {
  endpoint: string;
  method: string;
  status: 'PASS' | 'FAIL' | 'SKIP';
  statusCode?: number;
  message?: string;
  responseTime?: number;
}

class APITester {
  private results: TestResult[] = [];
  private adminToken: string = '';
  private userToken: string = '';

  // Color codes for console output
  private colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    cyan: '\x1b[36m',
    blue: '\x1b[34m'
  };

  constructor() {
    console.log(`${this.colors.cyan}${this.colors.bright}
╔══════════════════════════════════════════╗
║     API ENDPOINT TESTING SUITE           ║
║     True OTP Application                 ║
╚══════════════════════════════════════════╝${this.colors.reset}\n`);
  }

  private log(type: 'info' | 'success' | 'error' | 'warning', message: string) {
    const colors = {
      info: this.colors.blue,
      success: this.colors.green,
      error: this.colors.red,
      warning: this.colors.yellow
    };
    const icons = {
      info: 'ℹ',
      success: '✓',
      error: '✗',
      warning: '⚠'
    };
    console.log(`${colors[type]}${icons[type]} ${message}${this.colors.reset}`);
  }

  private async testEndpoint(
    endpoint: string,
    method: string,
    options?: {
      headers?: Record<string, string>;
      body?: any;
      expectedStatus?: number;
    }
  ): Promise<TestResult> {
    const startTime = Date.now();
    const fullUrl = `${BASE_URL}${endpoint}`;
    
    try {
      const response = await fetch(fullUrl, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers
        },
        body: options?.body ? JSON.stringify(options.body) : undefined
      });

      const responseTime = Date.now() - startTime;
      const expectedStatus = options?.expectedStatus || 200;
      
      const result: TestResult = {
        endpoint,
        method,
        status: response.status === expectedStatus ? 'PASS' : 'FAIL',
        statusCode: response.status,
        responseTime,
        message: response.status === expectedStatus 
          ? `Response: ${response.status} (${responseTime}ms)`
          : `Expected ${expectedStatus}, got ${response.status}`
      };

      // Log result
      if (result.status === 'PASS') {
        this.log('success', `${method} ${endpoint} - ${result.message}`);
      } else {
        this.log('error', `${method} ${endpoint} - ${result.message}`);
      }

      this.results.push(result);
      return result;
    } catch (error: any) {
      const result: TestResult = {
        endpoint,
        method,
        status: 'FAIL',
        message: error.message
      };
      this.log('error', `${method} ${endpoint} - ${error.message}`);
      this.results.push(result);
      return result;
    }
  }

  async runTests() {
    console.log(`${this.colors.bright}Starting API Tests...${this.colors.reset}\n`);

    // 1. Authentication Tests
    console.log(`${this.colors.cyan}${this.colors.bright}━━━ Authentication Endpoints ━━━${this.colors.reset}`);
    
    // Register new user
    await this.testEndpoint('/auth/register-initiate', 'POST', {
      body: { phone: TEST_USER_PHONE },
      expectedStatus: 200
    });

    // Login as test user
    const loginResult = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        identifier: TEST_USER_EMAIL,
        password: TEST_USER_PASSWORD
      })
    });
    
    if (loginResult.ok) {
      const loginData = await loginResult.json();
      if (loginData.success && loginData.data?.token) {
        this.userToken = loginData.data.token;
        this.log('success', 'User authentication successful');
      }
    }

    // Test auth endpoints
    await this.testEndpoint('/auth/me', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });
    
    await this.testEndpoint('/auth/profile', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    await this.testEndpoint('/auth/settings', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    await this.testEndpoint('/auth/request-qr', 'POST', {
      body: { phone: TEST_USER_PHONE }
    });

    await this.testEndpoint('/auth/logout', 'POST', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    // 2. Admin Authentication
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Admin Authentication ━━━${this.colors.reset}`);
    
    // Get NextAuth session for admin
    await this.testEndpoint('/auth/[...nextauth]', 'POST', {
      expectedStatus: 405 // NextAuth endpoint
    });

    // 3. Public Endpoints
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Public Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/packages', 'GET');
    await this.testEndpoint('/contact', 'POST', {
      body: {
        name: 'Test User',
        email: 'test@example.com',
        phone: '+919876543210',
        message: 'Test message'
      }
    });

    // 4. Protected User Endpoints
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Protected User Endpoints ━━━${this.colors.reset}`);
    
    await this.testEndpoint('/sessions', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });
    
    await this.testEndpoint('/usage', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });
    
    await this.testEndpoint('/usage-logs', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });
    
    await this.testEndpoint('/transactions', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    await this.testEndpoint('/dashboard/tickets', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    await this.testEndpoint('/credentials', 'GET', {
      headers: { Authorization: `Bearer ${this.userToken}` }
    });

    // 5. Admin Endpoints (require NextAuth admin session)
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Admin Endpoints ━━━${this.colors.reset}`);
    
    // These will fail without proper NextAuth session
    await this.testEndpoint('/admin/summary', 'GET', {
      expectedStatus: 401 // Unauthorized without session
    });
    
    await this.testEndpoint('/admin/users', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/transactions', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/usage-logs', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/tickets', 'GET', {
      expectedStatus: 401
    });
    
    await this.testEndpoint('/admin/sessions', 'GET', {
      expectedStatus: 401
    });

    // 6. Middleware Test
    console.log(`\n${this.colors.cyan}${this.colors.bright}━━━ Middleware Tests ━━━${this.colors.reset}`);
    
    // Test unauthorized access
    await this.testEndpoint('/sessions', 'GET', {
      expectedStatus: 401 // Should fail without token
    });
    
    // Test with invalid token
    await this.testEndpoint('/sessions', 'GET', {
      headers: { Authorization: 'Bearer invalid-token' },
      expectedStatus: 401
    });

    // Print summary
    this.printSummary();
  }

  private printSummary() {
    const passed = this.results.filter(r => r.status === 'PASS').length;
    const failed = this.results.filter(r => r.status === 'FAIL').length;
    const total = this.results.length;
    const avgResponseTime = this.results
      .filter(r => r.responseTime)
      .reduce((acc, r) => acc + (r.responseTime || 0), 0) / 
      this.results.filter(r => r.responseTime).length;

    console.log(`\n${this.colors.cyan}${this.colors.bright}
╔══════════════════════════════════════════╗
║           TEST SUMMARY                   ║
╚══════════════════════════════════════════╝${this.colors.reset}

${this.colors.bright}Total Tests:${this.colors.reset} ${total}
${this.colors.green}✓ Passed:${this.colors.reset} ${passed}
${this.colors.red}✗ Failed:${this.colors.reset} ${failed}
${this.colors.blue}⚡ Avg Response Time:${this.colors.reset} ${avgResponseTime.toFixed(2)}ms

${this.colors.bright}Success Rate:${this.colors.reset} ${((passed / total) * 100).toFixed(1)}%
`);

    // List failed tests
    if (failed > 0) {
      console.log(`${this.colors.red}${this.colors.bright}Failed Tests:${this.colors.reset}`);
      this.results
        .filter(r => r.status === 'FAIL')
        .forEach(r => {
          console.log(`  ${this.colors.red}✗ ${r.method} ${r.endpoint} - ${r.message}${this.colors.reset}`);
        });
    }
  }
}

// Run tests
const tester = new APITester();
tester.runTests().catch(console.error);
