"use client";

import { motion } from 'framer-motion';
import { 
  TrendingUp, Activity, CreditCard, Shield, 
  ChevronRight, ArrowUpRight, ArrowDownRight,
  Sparkles, Zap, Star
} from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: string;
  icon: any;
  color: string;
  delay?: number;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring" as const,
      stiffness: 100
    }
  }
};

export function MetricCard({ title, value, change, icon: Icon, color, delay = 0 }: MetricCardProps) {
  const isPositive = change?.startsWith('+');
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, type: "spring", stiffness: 100 }}
      whileHover={{ scale: 1.02, y: -5 }}
      className={`relative overflow-hidden bg-gradient-to-br ${color} backdrop-blur-sm border border-white/20 rounded-2xl p-6 shadow-xl`}
    >
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white animate-pulse-slow" />
        <div className="absolute -left-8 -bottom-8 w-32 h-32 rounded-full bg-white animate-pulse-slow animation-delay-2000" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <motion.div 
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
            className="p-3 bg-white/20 backdrop-blur-sm rounded-xl"
          >
            <Icon className="w-6 h-6 text-white" />
          </motion.div>
          
          {change && (
            <motion.span 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: delay + 0.2 }}
              className={`flex items-center gap-1 text-sm px-2 py-1 rounded-full ${
                isPositive 
                  ? 'bg-green-400/20 text-green-300' 
                  : 'bg-red-400/20 text-red-300'
              }`}
            >
              {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              {change}
            </motion.span>
          )}
        </div>
        
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: delay + 0.1 }}
          className="text-3xl font-bold text-white mb-1"
        >
          {value}
        </motion.div>
        <div className="text-white/80 text-sm">{title}</div>
        
        {/* Progress bar */}
        <div className="mt-4 h-1 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-white/50"
            initial={{ width: 0 }}
            animate={{ width: `${Math.random() * 60 + 40}%` }}
            transition={{ duration: 1, delay: delay + 0.3 }}
          />
        </div>
      </div>
    </motion.div>
  );
}

export function WelcomeSection({ userName }: { userName: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-8"
    >
      <div className="flex items-center justify-between">
        <div>
          <motion.h1 
            className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2"
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            Welcome back, {userName}! ✨
          </motion.h1>
          <motion.p 
            className="text-white/70 text-lg"
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Here's your dashboard overview for today
          </motion.p>
        </div>
        
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
          className="hidden md:flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-full"
        >
          <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
          <span className="text-sm text-blue-300">Premium Member</span>
        </motion.div>
      </div>
    </motion.div>
  );
}

export function QuickActionCard({ icon: Icon, title, description, onClick, color = "from-blue-600/20 to-purple-600/20" }: any) {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`w-full p-6 bg-gradient-to-br ${color} backdrop-blur-sm border border-white/20 rounded-2xl text-left group transition-all hover:shadow-xl`}
    >
      <div className="flex items-start gap-4">
        <motion.div
          whileHover={{ rotate: 360 }}
          transition={{ duration: 0.5 }}
          className="p-3 bg-white/20 rounded-xl group-hover:bg-white/30 transition-colors"
        >
          <Icon className="w-6 h-6 text-white" />
        </motion.div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-white mb-1">{title}</h3>
          <p className="text-white/70 text-sm">{description}</p>
        </div>
        <ChevronRight className="w-5 h-5 text-white/40 group-hover:text-white transition-colors mt-1" />
      </div>
    </motion.button>
  );
}

export function AnimatedTable({ headers, data, renderRow }: any) {
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="overflow-x-auto"
    >
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/20">
            {headers.map((header: string, index: number) => (
              <motion.th
                key={header}
                variants={itemVariants}
                className="text-left py-3 px-4 text-white/80 text-sm font-medium"
              >
                {header}
              </motion.th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((item: any, index: number) => (
            <motion.tr
              key={item.id || index}
              variants={itemVariants}
              whileHover={{ backgroundColor: "rgba(255, 255, 255, 0.05)" }}
              className="border-b border-white/10 transition-colors"
            >
              {renderRow(item, index)}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </motion.div>
  );
}

export function TabNavigation({ tabs, activeTab, onTabChange }: any) {
  return (
    <div className="flex gap-1 mb-6 bg-white/5 p-1 rounded-xl">
      {tabs.map((tab: any) => (
        <motion.button
          key={tab.id}
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onTabChange(tab.id)}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all ${
            activeTab === tab.id
              ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
              : 'text-white/60 hover:text-white hover:bg-white/10'
          }`}
        >
          <tab.icon className="w-4 h-4" />
          <span className="font-medium">{tab.label}</span>
          {tab.badge && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="px-2 py-0.5 text-xs bg-red-500 rounded-full text-white"
            >
              {tab.badge}
            </motion.span>
          )}
        </motion.button>
      ))}
    </div>
  );
}

export function AnimatedLoader() {
  return (
    <div className="flex items-center justify-center p-8">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full"
      />
    </div>
  );
}

export function FeatureHighlight({ icon: Icon, title, description }: any) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="p-6 bg-gradient-to-br from-blue-600/10 to-purple-600/10 backdrop-blur-sm border border-white/10 rounded-2xl"
    >
      <Icon className="w-8 h-8 text-blue-400 mb-3" />
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      <p className="text-white/70 text-sm">{description}</p>
    </motion.div>
  );
}
