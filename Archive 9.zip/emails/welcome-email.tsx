import * as React from 'react';

interface WelcomeEmailProps {
  name: string;
  loginUrl: string;
  supportEmail: string;
}

const EmailLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{
    fontFamily: 'Arial, sans-serif',
    lineHeight: '1.6',
    color: '#333333',
    maxWidth: '600px',
    margin: '0 auto',
    padding: '20px'
  }}>
    {children}
  </div>
);

const Header = ({ name }: { name: string }) => (
  <div style={{
    textAlign: 'center',
    marginBottom: '30px'
  }}>
    <h1 style={{
      color: '#4F46E5',
      marginBottom: '10px'
    }}>Welcome to TruOTP, {name}!</h1>
    <p style={{
      fontSize: '16px',
      marginBottom: '0'
    }}>Your account has been successfully created.</p>
  </div>
);

const Content = ({ children }: { children: React.ReactNode }) => (
  <div style={{
    backgroundColor: '#F9FAFB',
    padding: '25px',
    borderRadius: '8px',
    marginBottom: '30px'
  }}>
    {children}
  </div>
);

const Footer = ({ supportEmail }: { supportEmail: string }) => (
  <div style={{
    borderTop: '1px solid #E5E7EB',
    paddingTop: '20px',
    fontSize: '14px',
    color: '#6B7280'
  }}>
    <p style={{
      marginBottom: '10px'
    }}>If you didn't create this account, please contact our support team immediately at <a href={`mailto:${supportEmail}`} style={{
      color: '#4F46E5',
      textDecoration: 'none'
    }}>{supportEmail}</a>.</p>
    
    <p style={{
      marginBottom: '0',
      fontSize: '13px',
      color: '#9CA3AF'
    }}>© {new Date().getFullYear()} TruOTP. All rights reserved.</p>
  </div>
);

export const WelcomeEmail = ({
  name,
  loginUrl,
  supportEmail,
}: WelcomeEmailProps) => {
  return (
    <EmailLayout>
      <Header name={name} />
      
      <Content>
        <h2 style={{
          color: '#111827',
          fontSize: '18px',
          marginTop: '0',
          marginBottom: '20px'
        }}>Get Started with TruOTP</h2>
        
        <p>We're thrilled to have you on board! Here's what you can do next:</p>
        
        <ul style={{
          paddingLeft: '20px',
          margin: '15px 0',
          listStyleType: 'disc'
        }}>
          <li>Access your dashboard to manage your account</li>
          <li>Set up two-factor authentication for added security</li>
          <li>Explore our API documentation for integration options</li>
        </ul>
        
        <div style={{
          margin: '25px 0',
          textAlign: 'center'
        }}>
          <a href={loginUrl} style={{
            backgroundColor: '#4F46E5',
            color: '#FFFFFF',
            padding: '12px 24px',
            borderRadius: '6px',
            textDecoration: 'none',
            display: 'inline-block',
            fontWeight: '600'
          }}>Go to Dashboard</a>
        </div>
      </Content>
      
      <Footer supportEmail={supportEmail} />
    </EmailLayout>
  );
}

export const WelcomeEmailText = ({
  name,
  loginUrl,
  supportEmail,
}: WelcomeEmailProps) => `
Welcome to TruOTP, ${name}!

Your account has been successfully created.

GET STARTED WITH TRUOTP
-----------------------
We're thrilled to have you on board! Here's what you can do next:

• Access your dashboard to manage your account
• Set up two-factor authentication for added security
• Explore our API documentation for integration options

Go to your dashboard: ${loginUrl}

If you didn't create this account, please contact our support team immediately at ${supportEmail}.

© ${new Date().getFullYear()} TruOTP. All rights reserved.
`;
