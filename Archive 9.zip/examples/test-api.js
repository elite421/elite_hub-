#!/usr/bin/env node

/**
 * TrueOTP API Test Suite
 * Comprehensive testing for all API endpoints
 * 
 * Usage: node test-api.js [environment]
 * Example: node test-api.js local
 */

const TrueOTPClient = require('./trueotp-client.js');
const crypto = require('crypto');

// Test configuration
const config = {
  local: {
    baseURL: 'http://localhost:3002/api',  // Updated to correct port
    botURL: 'http://localhost:4002',
    testPhone: '9123456789',
    testEmail: 'test@example.com',
    testPassword: 'TestPass123!',
    botInternalKey: 'dev-secret-key'
  },
  staging: {
    baseURL: 'https://staging.truotp.com/api',
    botURL: 'https://staging-bot.truotp.com',
    testPhone: '9123456789',
    testEmail: 'test@staging.com',
    testPassword: 'StagingPass123!',
    botInternalKey: process.env.STAGING_BOT_KEY
  },
  production: {
    baseURL: 'https://api.truotp.com',
    botURL: 'https://bot.truotp.com',
    testPhone: '9123456789',
    testEmail: 'test@production.com',
    testPassword: 'ProdPass123!',
    botInternalKey: process.env.PROD_BOT_KEY
  }
};

// Get environment from command line
const env = process.argv[2] || 'local';
const testConfig = config[env];

if (!testConfig) {
  console.error(`❌ Invalid environment: ${env}`);
  console.log('Available environments: local, staging, production');
  process.exit(1);
}

console.log(`\n🚀 Testing TrueOTP API - ${env.toUpperCase()} Environment`);
console.log(`API URL: ${testConfig.baseURL}`);
console.log(`Bot URL: ${testConfig.botURL}\n`);

// Initialize client
const client = new TrueOTPClient({
  baseURL: testConfig.baseURL,
  debug: false,
  timeout: 10000
});

// Test results
const results = {
  passed: 0,
  failed: 0,
  skipped: 0,
  tests: []
};

// Helper functions
function generateTestPhone() {
  const random = Math.floor(Math.random() * 1000000);
  return `91999${random}`;
}

function generateTestEmail() {
  const random = crypto.randomBytes(4).toString('hex');
  return `test_${random}@example.com`;
}

async function runTest(name, testFn) {
  process.stdout.write(`Testing ${name}... `);
  
  try {
    const startTime = Date.now();
    await testFn();
    const duration = Date.now() - startTime;
    
    console.log(`✅ PASSED (${duration}ms)`);
    results.passed++;
    results.tests.push({ name, status: 'passed', duration });
  } catch (error) {
    console.log(`❌ FAILED`);
    console.error(`  Error: ${error.message}`);
    results.failed++;
    results.tests.push({ name, status: 'failed', error: error.message });
  }
}

async function skipTest(name, reason) {
  console.log(`⚠️  Skipping ${name}: ${reason}`);
  results.skipped++;
  results.tests.push({ name, status: 'skipped', reason });
}

// Test Suite
async function runTestSuite() {
  console.log('📝 Starting Test Suite...\n');
  
  // Store test data
  let testUser = null;
  let authToken = null;
  
  // ============= Public Endpoints =============
  console.log('=== PUBLIC ENDPOINTS ===\n');
  
  // Test 1: Request WhatsApp QR
  await runTest('Request WhatsApp QR', async () => {
    const result = await client.requestWhatsAppQR(testConfig.testPhone);
    
    if (!result.success) {
      throw new Error(result.message);
    }
    
    if (!result.data.qrCode) {
      throw new Error('No QR code returned');
    }
    
    if (!result.data.qrCode.startsWith('data:image/')) {
      throw new Error('Invalid QR code format');
    }
  });
  
  // Test 2: Password Login with invalid credentials
  await runTest('Invalid Password Login', async () => {
    const result = await client.login('invalid@email.com', 'wrongpass');
    
    if (result.success) {
      throw new Error('Should have failed with invalid credentials');
    }
    
    if (!result.message.toLowerCase().includes('invalid')) {
      throw new Error('Unexpected error message');
    }
  });
  
  // Test 3: Registration Initiate
  const testPhone = generateTestPhone();
  const testEmail = generateTestEmail();
  
  await runTest('Registration Initiate', async () => {
    const response = await fetch(`${testConfig.baseURL}/auth/register-initiate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phone: testPhone,
        email: testEmail,
        name: 'Test User'
      })
    });
    
    const result = await response.json();
    
    // It may fail if WhatsApp bot is not configured
    if (!result.success && !result.message.includes('OTP')) {
      throw new Error(result.message);
    }
  });
  
  // Test 4: Password Reset Initiate
  await runTest('Password Reset Initiate', async () => {
    const response = await fetch(`${testConfig.baseURL}/auth/password-reset-initiate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        identifier: testConfig.testEmail
      })
    });
    
    const result = await response.json();
    
    // May fail if user doesn't exist or WhatsApp not configured
    if (!result.success && !result.message.includes('not found') && !result.message.includes('OTP')) {
      throw new Error(result.message);
    }
  });
  
  // ============= Create Test User for Auth Tests =============
  console.log('\n=== SETUP TEST USER ===\n');
  
  // For local testing, we'll skip auth-required tests if we can't create a user
  if (env === 'local') {
    await skipTest('Create Test User', 'Requires manual database setup or existing user');
    
    // Try to login with a default test user if it exists
    try {
      const loginResult = await client.login(testConfig.testEmail, testConfig.testPassword);
      if (loginResult.success) {
        authToken = loginResult.data.token;
        testUser = loginResult.data.user;
        console.log('✅ Using existing test user\n');
      }
    } catch (e) {
      console.log('⚠️  No test user available, skipping authenticated tests\n');
    }
  }
  
  // ============= Authenticated Endpoints =============
  if (authToken) {
    console.log('=== AUTHENTICATED ENDPOINTS ===\n');
    
    // Test 5: Get Current User
    await runTest('Get Current User', async () => {
      const result = await client.getCurrentUser();
      
      if (!result.success) {
        throw new Error(result.message);
      }
      
      if (!result.data || !result.data.id) {
        throw new Error('Invalid user data');
      }
    });
    
    // Test 6: Get Profile
    await runTest('Get Profile', async () => {
      const result = await client.getProfile();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 7: Get Sessions
    await runTest('Get Sessions', async () => {
      const result = await client.getSessions();
      
      if (!result.success) {
        throw new Error(result.message);
      }
      
      if (!Array.isArray(result.data)) {
        throw new Error('Sessions should be an array');
      }
    });
    
    // Test 8: Get Usage
    await runTest('Get Usage', async () => {
      const result = await client.getUsage();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 9: Get Usage Logs
    await runTest('Get Usage Logs', async () => {
      const result = await client.getUsageLogs();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 10: Get Transactions
    await runTest('Get Transactions', async () => {
      const result = await client.getTransactions();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 11: Get Packages
    await runTest('Get Packages', async () => {
      const result = await client.getPackages();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 12: Get Credentials
    await runTest('Get Credentials', async () => {
      const result = await client.getCredentials();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
    
    // Test 13: Update Settings
    await runTest('Update Settings', async () => {
      const result = await client.updateSettings({
        notifications: true
      });
      
      // May not be implemented
      if (!result.success && !result.message.includes('not found')) {
        throw new Error(result.message);
      }
    });
    
    // Test 14: Submit Support Ticket
    await runTest('Submit Support Ticket', async () => {
      const result = await client.submitTicket(
        'API Test Ticket',
        'This is an automated test ticket from the API test suite.'
      );
      
      // May not be implemented
      if (!result.success && !result.message.includes('not found')) {
        throw new Error(result.message);
      }
    });
    
  } else {
    console.log('=== SKIPPING AUTHENTICATED TESTS ===\n');
    await skipTest('Authenticated Endpoints', 'No authentication token available');
  }
  
  // ============= Bot Service Tests =============
  if (env === 'local') {
    console.log('\n=== BOT SERVICE TESTS ===\n');
    
    // Test 15: Bot Health Check
    await runTest('Bot Health Check', async () => {
      const response = await fetch(`${testConfig.botURL}/health`);
      
      if (!response.ok) {
        throw new Error(`Bot service returned ${response.status}`);
      }
      
      const data = await response.json();
      
      if (!data.ok) {
        throw new Error('Bot health check failed');
      }
    });
    
    // Test 16: Bot QR Endpoint
    await runTest('Bot QR Endpoint', async () => {
      const response = await fetch(`${testConfig.botURL}/qr.json`);
      const data = await response.json();
      
      // QR might not be available if bot is already authenticated
      if (!data.ok && !data.message.includes('No QR')) {
        throw new Error(data.message);
      }
    });
    
    // Test 17: Bot Send Message (requires internal key)
    await runTest('Bot Send Message', async () => {
      const response = await fetch(`${testConfig.botURL}/send-message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-internal-key': testConfig.botInternalKey
        },
        body: JSON.stringify({
          phone: testConfig.testPhone,
          text: 'Test message from API test suite'
        })
      });
      
      const data = await response.json();
      
      // May fail if WhatsApp not connected
      if (!data.success && !data.message.includes('not ready')) {
        throw new Error(data.message);
      }
    });
  }
  
  // ============= Performance Tests =============
  console.log('\n=== PERFORMANCE TESTS ===\n');
  
  // Test 18: Response Time
  await runTest('API Response Time', async () => {
    const startTime = Date.now();
    
    // Make 10 requests
    const promises = [];
    for (let i = 0; i < 10; i++) {
      promises.push(
        fetch(`${testConfig.baseURL}/health`).catch(() => null)
      );
    }
    
    await Promise.all(promises);
    const avgTime = (Date.now() - startTime) / 10;
    
    if (avgTime > 1000) {
      throw new Error(`Average response time too high: ${avgTime}ms`);
    }
  });
  
  // Test 19: Rate Limiting
  await runTest('Rate Limiting', async () => {
    // Make rapid requests to test rate limiting
    const promises = [];
    for (let i = 0; i < 20; i++) {
      promises.push(
        client.requestWhatsAppQR(generateTestPhone())
      );
    }
    
    const results = await Promise.allSettled(promises);
    const rateLimited = results.some(r => 
      r.status === 'rejected' && 
      r.reason.message.includes('429')
    );
    
    // Rate limiting should be in place
    if (!rateLimited && env !== 'local') {
      console.warn('  Warning: No rate limiting detected');
    }
  });
  
  // ============= Cleanup =============
  if (authToken) {
    console.log('\n=== CLEANUP ===\n');
    
    // Test 20: Logout
    await runTest('Logout', async () => {
      const result = await client.logout();
      
      if (!result.success) {
        throw new Error(result.message);
      }
    });
  }
  
  // ============= Test Summary =============
  console.log('\n' + '='.repeat(50));
  console.log('TEST SUMMARY');
  console.log('='.repeat(50));
  console.log(`✅ Passed: ${results.passed}`);
  console.log(`❌ Failed: ${results.failed}`);
  console.log(`⚠️  Skipped: ${results.skipped}`);
  console.log(`📊 Total: ${results.passed + results.failed + results.skipped}`);
  console.log('='.repeat(50));
  
  // Generate report
  if (results.failed > 0) {
    console.log('\n❌ FAILED TESTS:');
    results.tests
      .filter(t => t.status === 'failed')
      .forEach(t => {
        console.log(`  - ${t.name}: ${t.error}`);
      });
  }
  
  // Exit with appropriate code
  process.exit(results.failed > 0 ? 1 : 0);
}

// Handle errors
process.on('unhandledRejection', (error) => {
  console.error('\n💥 Unhandled error:', error);
  process.exit(1);
});

// Run the test suite
runTestSuite().catch((error) => {
  console.error('\n💥 Test suite failed:', error);
  process.exit(1);
});
