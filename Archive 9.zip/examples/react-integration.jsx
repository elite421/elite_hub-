/**
 * React Integration Example for TrueOTP API
 * This example shows how to integrate TrueOTP authentication in a React application
 */

import React, { useState, useEffect, useCallback } from 'react';
import TrueOTPClient from './trueotp-client';

// Initialize client
const client = new TrueOTPClient({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:3000/api',
  debug: process.env.NODE_ENV === 'development'
});

// ============= Authentication Context =============
const AuthContext = React.createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Check if user is already logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('trueotp_token');
        if (token) {
          const result = await client.getCurrentUser();
          if (result.success) {
            setUser(result.data);
          }
        }
      } catch (err) {
        console.error('Auth check failed:', err);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const logout = async () => {
    try {
      await client.logout();
      setUser(null);
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, error, setError, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => React.useContext(AuthContext);

// ============= WhatsApp QR Login Component =============
export function WhatsAppLogin() {
  const { setUser, setError } = useAuth();
  const [phone, setPhone] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  const requestQR = async () => {
    if (!phone || phone.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      // Request QR code
      const result = await client.requestWhatsAppQR(phone);
      
      if (result.success) {
        setQrCode(result.data.qrCode);
        setStatus('QR code generated. Please scan with WhatsApp.');
        
        // Extract hash from QR data for polling
        const hash = result.data.qrCode.split('text=')[1]?.substring(0, 10);
        
        // Start polling for verification
        pollVerification(hash);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const pollVerification = async (hash) => {
    try {
      const result = await client.pollQRVerification(
        hash,
        (status) => {
          if (status.data?.verified) {
            setStatus('✅ Verification successful! Logging you in...');
          } else {
            setStatus('⏳ Waiting for WhatsApp verification...');
          }
        },
        2000,  // Poll every 2 seconds
        300000 // Timeout after 5 minutes
      );

      if (result.success) {
        // Get user data
        const userResult = await client.getCurrentUser();
        if (userResult.success) {
          setUser(userResult.data);
          setStatus('✅ Login successful!');
          
          // Redirect to dashboard
          setTimeout(() => {
            window.location.href = '/dashboard';
          }, 1000);
        }
      }
    } catch (err) {
      setError('Verification timeout. Please try again.');
      setQrCode(null);
    }
  };

  return (
    <div className="whatsapp-login">
      <h2>WhatsApp QR Login</h2>
      
      {!qrCode ? (
        <div className="phone-input">
          <input
            type="tel"
            placeholder="Enter phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            disabled={loading}
          />
          <button onClick={requestQR} disabled={loading}>
            {loading ? 'Generating...' : 'Generate QR Code'}
          </button>
        </div>
      ) : (
        <div className="qr-display">
          <img src={qrCode} alt="WhatsApp QR Code" />
          <p className="status">{status}</p>
          <button onClick={() => {
            setQrCode(null);
            setStatus('');
          }}>
            Cancel
          </button>
        </div>
      )}
    </div>
  );
}

// ============= Password Login Component =============
export function PasswordLogin() {
  const { setUser, setError } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await client.login(identifier, password);
      
      if (result.success) {
        setUser(result.data.user);
        window.location.href = '/dashboard';
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="password-login" onSubmit={handleSubmit}>
      <h2>Password Login</h2>
      
      <input
        type="text"
        placeholder="Email or Phone"
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
        required
        disabled={loading}
      />
      
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        disabled={loading}
      />
      
      <button type="submit" disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
}

// ============= Registration Component =============
export function Registration() {
  const { setUser, setError } = useAuth();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    phone: '',
    email: '',
    name: '',
    otp: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);

  const handleInitiate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await client.registerInitiate({
        phone: formData.phone,
        email: formData.email,
        name: formData.name
      });

      if (result.success) {
        setStep(2);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await client.registerVerify(
        formData.phone,
        formData.otp,
        formData.password
      );

      if (result.success) {
        setUser(result.data.user);
        window.location.href = '/dashboard';
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="registration">
      <h2>Register</h2>
      
      {step === 1 ? (
        <form onSubmit={handleInitiate}>
          <input
            type="text"
            placeholder="Name"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
          
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
          
          <input
            type="tel"
            placeholder="Phone"
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
            required
          />
          
          <button type="submit" disabled={loading}>
            {loading ? 'Sending OTP...' : 'Send OTP'}
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerify}>
          <input
            type="text"
            placeholder="Enter OTP"
            value={formData.otp}
            onChange={(e) => setFormData({...formData, otp: e.target.value})}
            required
          />
          
          <input
            type="password"
            placeholder="Create Password"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            required
          />
          
          <button type="submit" disabled={loading}>
            {loading ? 'Verifying...' : 'Complete Registration'}
          </button>
          
          <button type="button" onClick={() => setStep(1)}>
            Back
          </button>
        </form>
      )}
    </div>
  );
}

// ============= Dashboard Component =============
export function Dashboard() {
  const { user, logout } = useAuth();
  const [usage, setUsage] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const [usageResult, sessionsResult] = await Promise.all([
          client.getUsage(),
          client.getSessions()
        ]);

        if (usageResult.success) {
          setUsage(usageResult.data);
        }
        
        if (sessionsResult.success) {
          setSessions(sessionsResult.data);
        }
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const revokeOtherSessions = async () => {
    try {
      const result = await client.revokeOtherSessions();
      if (result.success) {
        alert('All other sessions have been revoked');
        // Reload sessions
        const sessionsResult = await client.getSessions();
        if (sessionsResult.success) {
          setSessions(sessionsResult.data);
        }
      }
    } catch (err) {
      alert('Failed to revoke sessions: ' + err.message);
    }
  };

  if (!user) {
    return <div>Please login to view dashboard</div>;
  }

  if (loading) {
    return <div>Loading dashboard...</div>;
  }

  return (
    <div className="dashboard">
      <header>
        <h1>Welcome, {user.name || user.phone}</h1>
        <button onClick={logout}>Logout</button>
      </header>

      <section className="user-info">
        <h2>Account Information</h2>
        <p>Phone: {user.phone}</p>
        <p>Email: {user.email || 'Not provided'}</p>
      </section>

      {usage && (
        <section className="usage-stats">
          <h2>Usage Statistics</h2>
          <p>Total Requests: {usage.totalRequests || 0}</p>
          <p>This Month: {usage.monthlyRequests || 0}</p>
          <p>Remaining: {usage.remainingRequests || 'Unlimited'}</p>
        </section>
      )}

      <section className="sessions">
        <h2>Active Sessions</h2>
        <button onClick={revokeOtherSessions}>Revoke All Other Sessions</button>
        <ul>
          {sessions.map((session, index) => (
            <li key={index}>
              {session.device} - {session.ip} - {new Date(session.createdAt).toLocaleString()}
              {session.current && ' (Current)'}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

// ============= Main App Component =============
export default function App() {
  const { error } = useAuth();

  return (
    <div className="app">
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/" element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    </div>
  );
}

// Login page with both methods
function LoginPage() {
  const [method, setMethod] = useState('whatsapp');

  return (
    <div className="login-page">
      <div className="method-selector">
        <button 
          className={method === 'whatsapp' ? 'active' : ''}
          onClick={() => setMethod('whatsapp')}
        >
          WhatsApp Login
        </button>
        <button 
          className={method === 'password' ? 'active' : ''}
          onClick={() => setMethod('password')}
        >
          Password Login
        </button>
      </div>

      {method === 'whatsapp' ? <WhatsAppLogin /> : <PasswordLogin />}
    </div>
  );
}
