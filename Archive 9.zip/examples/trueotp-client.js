/**
 * TrueOTP API Client Library
 * A complete JavaScript/TypeScript client for integrating with TrueOTP API
 */

class TrueOTPClient {
  constructor(config = {}) {
    this.baseURL = config.baseURL || 'http://localhost:3000/api';
    this.token = null;
    this.debug = config.debug || false;
    this.timeout = config.timeout || 30000;
    this.retryAttempts = config.retryAttempts || 3;
    this.retryDelay = config.retryDelay || 1000;
  }

  // Logging helper
  log(message, data = null) {
    if (this.debug) {
      console.log(`[TrueOTP] ${message}`, data || '');
    }
  }

  // Sleep helper for retries
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Core request method with retry logic
  async request(endpoint, options = {}, authenticated = false) {
    const url = `${this.baseURL}${endpoint}`;
    let lastError;

    for (let attempt = 0; attempt < this.retryAttempts; attempt++) {
      try {
        const headers = {
          'Content-Type': 'application/json',
          ...options.headers,
        };

        if (authenticated) {
          if (!this.token) {
            // Try to get token from localStorage
            if (typeof window !== 'undefined') {
              this.token = localStorage.getItem('trueotp_token');
            }
          }
          if (!this.token) {
            throw new Error('Authentication required. Please login first.');
          }
          headers['Authorization'] = `Bearer ${this.token}`;
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        const response = await fetch(url, {
          ...options,
          headers,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        const data = await response.json();

        if (!response.ok) {
          if (response.status === 401 && authenticated) {
            // Token expired or invalid
            this.clearToken();
            throw new Error('Session expired. Please login again.');
          }
          if (response.status === 429) {
            // Rate limited - wait and retry
            const retryAfter = response.headers.get('Retry-After') || 60;
            this.log(`Rate limited. Waiting ${retryAfter} seconds...`);
            await this.sleep(retryAfter * 1000);
            continue;
          }
          throw new Error(data.message || `HTTP ${response.status} error`);
        }

        this.log(`${options.method || 'GET'} ${endpoint} - Success`, data);
        return data;

      } catch (error) {
        lastError = error;
        this.log(`Attempt ${attempt + 1} failed:`, error.message);

        if (error.name === 'AbortError') {
          lastError = new Error('Request timeout');
        }

        if (attempt < this.retryAttempts - 1) {
          const delay = this.retryDelay * Math.pow(2, attempt);
          this.log(`Retrying in ${delay}ms...`);
          await this.sleep(delay);
        }
      }
    }

    throw lastError;
  }

  // Save token
  saveToken(token) {
    this.token = token;
    if (typeof window !== 'undefined') {
      localStorage.setItem('trueotp_token', token);
    }
    this.log('Token saved');
  }

  // Clear token
  clearToken() {
    this.token = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem('trueotp_token');
    }
    this.log('Token cleared');
  }

  // ============= Authentication Methods =============

  /**
   * Request WhatsApp QR code for login
   * @param {string} phone - Phone number (without country code)
   * @returns {Promise} QR code data and request info
   */
  async requestWhatsAppQR(phone) {
    const data = await this.request('/auth/request-whatsapp-qr', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });

    if (data.success) {
      this.log('WhatsApp QR generated', {
        requestId: data.data.requestId,
        expiresAt: data.data.expiresAt,
      });
    }

    return data;
  }

  /**
   * Verify WhatsApp hash code
   * @param {string} hash - 10-character hash code
   * @param {string} phone - Phone number
   * @returns {Promise} Login result with token
   */
  async verifyHashCode(hash, phone) {
    const data = await this.request('/auth/verify-hash-code', {
      method: 'POST',
      body: JSON.stringify({ hash, phone }),
    });

    if (data.success && data.data?.token) {
      this.saveToken(data.data.token);
    }

    return data;
  }

  /**
   * Check QR verification status
   * @param {string} hash - QR hash to check
   * @returns {Promise} Verification status
   */
  async checkQRStatus(hash) {
    return await this.request(`/auth/verify-qr-status/${hash}`, {
      method: 'GET',
    });
  }

  /**
   * Login with email/phone and password
   * @param {string} identifier - Email or phone number
   * @param {string} password - User password
   * @returns {Promise} Login result with token
   */
  async login(identifier, password) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });

    if (data.success && data.data?.token) {
      this.saveToken(data.data.token);
    }

    return data;
  }

  /**
   * Initiate registration with OTP
   * @param {object} userData - User registration data
   * @returns {Promise} Registration initiation result
   */
  async registerInitiate(userData) {
    return await this.request('/auth/register-initiate', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  /**
   * Complete registration with OTP verification
   * @param {string} phone - Phone number
   * @param {string} otp - OTP code
   * @param {string} password - User password
   * @returns {Promise} Registration result with token
   */
  async registerVerify(phone, otp, password) {
    const data = await this.request('/auth/register-verify', {
      method: 'POST',
      body: JSON.stringify({ phone, otp, password }),
    });

    if (data.success && data.data?.token) {
      this.saveToken(data.data.token);
    }

    return data;
  }

  /**
   * Initiate password reset
   * @param {string} identifier - Email or phone
   * @returns {Promise} Password reset initiation result
   */
  async passwordResetInitiate(identifier) {
    return await this.request('/auth/password-reset-initiate', {
      method: 'POST',
      body: JSON.stringify({ identifier }),
    });
  }

  /**
   * Complete password reset with OTP
   * @param {string} identifier - Email or phone
   * @param {string} otp - OTP code
   * @param {string} newPassword - New password
   * @returns {Promise} Password reset result
   */
  async passwordResetVerify(identifier, otp, newPassword) {
    return await this.request('/auth/password-reset-verify', {
      method: 'POST',
      body: JSON.stringify({ identifier, otp, newPassword }),
    });
  }

  /**
   * Logout current session
   * @returns {Promise} Logout result
   */
  async logout() {
    const data = await this.request('/auth/logout', {
      method: 'POST',
    }, true);

    if (data.success) {
      this.clearToken();
    }

    return data;
  }

  // ============= User Profile Methods =============

  /**
   * Get current user info
   * @returns {Promise} Current user data
   */
  async getCurrentUser() {
    return await this.request('/auth/me', {
      method: 'GET',
    }, true);
  }

  /**
   * Get user profile
   * @returns {Promise} User profile data
   */
  async getProfile() {
    return await this.request('/auth/profile', {
      method: 'GET',
    }, true);
  }

  /**
   * Update user settings
   * @param {object} settings - Settings to update
   * @returns {Promise} Update result
   */
  async updateSettings(settings) {
    return await this.request('/auth/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }, true);
  }

  // ============= Session Management =============

  /**
   * Get all active sessions
   * @returns {Promise} List of active sessions
   */
  async getSessions() {
    return await this.request('/sessions', {
      method: 'GET',
    }, true);
  }

  /**
   * Revoke all other sessions
   * @returns {Promise} Revoke result
   */
  async revokeOtherSessions() {
    return await this.request('/auth/revoke-others', {
      method: 'POST',
    }, true);
  }

  // ============= Usage & Analytics =============

  /**
   * Get usage statistics
   * @returns {Promise} Usage stats
   */
  async getUsage() {
    return await this.request('/usage', {
      method: 'GET',
    }, true);
  }

  /**
   * Get usage logs
   * @param {object} params - Query parameters
   * @returns {Promise} Usage logs
   */
  async getUsageLogs(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const endpoint = queryString ? `/usage-logs?${queryString}` : '/usage-logs';
    return await this.request(endpoint, {
      method: 'GET',
    }, true);
  }

  /**
   * Get transactions
   * @param {object} params - Query parameters
   * @returns {Promise} Transaction history
   */
  async getTransactions(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const endpoint = queryString ? `/transactions?${queryString}` : '/transactions';
    return await this.request(endpoint, {
      method: 'GET',
    }, true);
  }

  // ============= Package Management =============

  /**
   * Get available packages
   * @returns {Promise} List of packages
   */
  async getPackages() {
    return await this.request('/packages', {
      method: 'GET',
    }, true);
  }

  // ============= Credentials & Webhooks =============

  /**
   * Get API credentials
   * @returns {Promise} API credentials
   */
  async getCredentials() {
    return await this.request('/credentials', {
      method: 'GET',
    }, true);
  }

  /**
   * Update webhook URL
   * @param {string} webhookUrl - New webhook URL
   * @returns {Promise} Update result
   */
  async updateWebhook(webhookUrl) {
    return await this.request('/credentials', {
      method: 'POST',
      body: JSON.stringify({ webhookUrl }),
    }, true);
  }

  // ============= Support =============

  /**
   * Submit support ticket
   * @param {string} subject - Ticket subject
   * @param {string} message - Ticket message
   * @returns {Promise} Ticket submission result
   */
  async submitTicket(subject, message) {
    return await this.request('/contact', {
      method: 'POST',
      body: JSON.stringify({ subject, message }),
    }, true);
  }

  // ============= Utility Methods =============

  /**
   * Poll for WhatsApp QR verification
   * @param {string} hash - QR hash to check
   * @param {function} callback - Callback for status updates
   * @param {number} interval - Polling interval in ms
   * @param {number} timeout - Total timeout in ms
   * @returns {Promise} Verification result
   */
  async pollQRVerification(hash, callback, interval = 2000, timeout = 300000) {
    const startTime = Date.now();

    while (Date.now() - startTime < timeout) {
      try {
        const result = await this.checkQRStatus(hash);
        
        if (callback) {
          callback(result);
        }

        if (result.data?.verified) {
          // Successfully verified
          if (result.data.token) {
            this.saveToken(result.data.token);
          }
          return result;
        }

        await this.sleep(interval);
      } catch (error) {
        this.log('Polling error:', error);
        await this.sleep(interval);
      }
    }

    throw new Error('QR verification timeout');
  }

  /**
   * Format phone number with country code
   * @param {string} phone - Phone number
   * @param {string} countryCode - Country code (default: 91)
   * @returns {string} Formatted phone number
   */
  formatPhone(phone, countryCode = '91') {
    let digits = String(phone).replace(/\D/g, '');
    digits = digits.replace(/^0+/, '');
    
    if (!digits.startsWith(countryCode) && digits.length <= 10) {
      digits = `${countryCode}${digits}`;
    }
    
    return digits;
  }

  /**
   * Validate email address
   * @param {string} email - Email to validate
   * @returns {boolean} Is valid email
   */
  validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }

  /**
   * Validate phone number
   * @param {string} phone - Phone to validate
   * @returns {boolean} Is valid phone
   */
  validatePhone(phone) {
    const digits = String(phone).replace(/\D/g, '');
    return digits.length >= 10 && digits.length <= 15;
  }
}

// Export for different environments
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TrueOTPClient;
} else if (typeof window !== 'undefined') {
  window.TrueOTPClient = TrueOTPClient;
}
