import { NextRequest, NextResponse } from 'next/server';
import { generateSMSQR } from '@/lib/qr';
import { query } from '@/lib/db';
import crypto from 'crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  // Strict WhatsApp-only mode: this endpoint is disabled unless explicitly enabled
  const enableRegular = String(process.env.ENABLE_REGULAR_QR || '').toLowerCase() === 'true';
  if (!enableRegular) {
    return NextResponse.json({ success: false, message: 'Regular QR login is disabled' }, { status: 403 });
  }
  try {
    const { phone } = await req.json();
    if (!phone) return NextResponse.json({ success: false, message: 'Phone number is required' }, { status: 400 });
    const cleanPhone = String(phone).replace(/\D/g, '');

    const companyWhatsAppNumber = process.env.COMPANY_WHATSAPP_NUMBER || '919212079494';

    // 10-character alphanumeric hash (letters+numbers)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const bytes = crypto.randomBytes(10);
    let hash = '';
    for (let i = 0; i < 10; i++) {
      hash += chars[bytes[i] % chars.length];
    }
    const qr = await generateSMSQR(companyWhatsAppNumber, hash);

    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
    await query(`DELETE FROM login_requests WHERE phone = $1 AND is_verified = false`, [cleanPhone]);
    const ins = await query<{ id: number }>(
      `INSERT INTO login_requests (phone, hash_code, qr_code_data, expires_at)
       VALUES ($1, $2, $3, $4)
       RETURNING id`,
      [cleanPhone, hash, JSON.stringify({ phone: cleanPhone, type: 'login_request' }), expiresAt]
    );
    const requestId = ins.rows[0]?.id;

    return NextResponse.json({
      success: true,
      message: 'QR code generated successfully',
      data: {
        qrCode: qr.qrCode,
        expiresAt,
        requestId,
        companyNumber: companyWhatsAppNumber,
        instructions: `Scan this QR code with your phone's camera. It will open your messaging app with a pre-filled message. Simply send it to complete your login.`,
      },
    });
  } catch (e: any) {
    // eslint-disable-next-line no-console
    console.error('request-qr error:', e);
    return NextResponse.json({ success: false, message: 'Failed to generate QR code' }, { status: 500 });
  }
}
