import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sendEmail } from '@/lib/email';
import { requireAuth } from '@/lib/authApi';
import { query } from '@/lib/db';
import { signToken } from '@/lib/jwt';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function sendGreeting(email: string, name: string | null) {
  try {
    const appName = process.env.APP_NAME || 'TruOTP';
    const subject = `Welcome to ${appName}!`;
    const text = `Hello${name ? ` ${name}` : ''},

Thank you for verifying your account with ${appName}. Your account is now active and ready to use.

If you have any questions or need assistance, please don't hesitate to contact our support team.

Best regards,
The ${appName} Team`;

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to ${appName}${name ? `, ${name}` : ''}!</h2>
        <p>Thank you for verifying your account with ${appName}. Your account is now active and ready to use.</p>
        <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
        <p>Best regards,<br>The ${appName} Team</p>
      </div>
    `;

    const { sendEmail } = await import('@/lib/email');
    return await sendEmail({
      to: email,
      subject,
      text,
      html
    });
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error('sendGreeting error:', e);
    return false;
  }
}

export async function POST(req: NextRequest) {
  try {
    // Require authenticated session (token from QR verification or JWT)
    let user;
    try {
      const auth = await requireAuth(req);
      user = auth.user;
    } catch (e) {
      // If no session, check for JWT in request body
      const { token, name, email, password, phone } = await req.json();
      
      if (!token) {
        return NextResponse.json({ success: false, message: 'Authentication required' }, { status: 401 });
      }
      
      // Verify the token is valid and get user ID
      const tokenRes = await query<{ user_id: number }>(
        'SELECT user_id FROM sessions WHERE token = $1 AND expires_at > NOW()',
        [token]
      );
      
      if (tokenRes.rows.length === 0) {
        return NextResponse.json({ success: false, message: 'Invalid or expired session' }, { status: 401 });
      }
      
      user = { id: tokenRes.rows[0].user_id };
      
      // Validate required fields
      if (!name || !email || !password || !phone) {
        return NextResponse.json(
          { success: false, message: 'Name, email, phone, and password are required' }, 
          { status: 400 }
        );
      }
      
      // Check if user exists and is not blocked
      const userRes = await query<{ is_blocked: boolean }>(
        'SELECT is_blocked FROM users WHERE id = $1',
        [user.id]
      );
      
      if (userRes.rows.length === 0) {
        return NextResponse.json({ success: false, message: 'User not found' }, { status: 404 });
      }
      
      if (userRes.rows[0].is_blocked) {
        return NextResponse.json(
          { success: false, message: 'Your account has been blocked. Please contact support.' }, 
          { status: 403 }
        );
      }
      
      // Update user data
      const hashed = await bcrypt.hash(String(password), 10);
      await query(
        `UPDATE users SET name = $1, email = $2, password = $3, phone = $4, is_verified = true WHERE id = $5`,
        [String(name), String(email).toLowerCase().trim(), hashed, String(phone).replace(/\D/g, ''), user.id]
      );
      
      // Send welcome email
      try {
        await sendEmail({
          to: String(email),
          subject: 'Welcome to TruOTP',
          text: `Hi ${String(name)},\n\nWelcome to TruOTP! Your account has been registered successfully.\n\n— Team TruOTP`,
          html: `<p>Hi ${String(name)},</p><p>Welcome to <strong>TruOTP</strong>! Your account has been registered successfully.</p><p>— Team TruOTP</p>`
        });
      } catch (e) {
        console.error('Failed to send welcome email:', e);
      }
      
      // Generate new session token
      const newToken = signToken({ userId: user.id, phone: String(phone), email: String(email) });
      
      // Update session
      await query(
        'UPDATE sessions SET token = $1, expires_at = NOW() + INTERVAL \'7 days\' WHERE user_id = $2',
        [newToken, user.id]
      );
      
      const response = NextResponse.json({ 
        success: true, 
        message: 'Registration completed',
        token: newToken
      });
      
      // Set HTTP-only cookie
      response.cookies.set('authToken', newToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        path: '/',
        maxAge: 60 * 60 * 24 * 7 // 7 days
      });
      
      return response;
    }

    // Existing session-based flow
    const { name, email, password } = await req.json();
    if (!name || !email || !password) {
      return NextResponse.json(
        { success: false, message: 'Name, email, and password are required' }, 
        { status: 400 }
      );
    }

    const cleanEmail = String(email).toLowerCase().trim();
    const hashed = await bcrypt.hash(String(password), 10);

    // Ensure email is not taken by someone else
    const dupRes = await query<{ id: number }>(
      `SELECT id FROM users WHERE email = $1 AND id <> $2 LIMIT 1`, 
      [cleanEmail, Number(user.id)]
    );
    
    if (dupRes.rows.length > 0) {
      return NextResponse.json(
        { success: false, message: 'Email already in use' }, 
        { status: 400 }
      );
    }

    // Update user with new information
    await query(
      `UPDATE users 
       SET name = $1, email = $2, password = $3, is_verified = true 
       WHERE id = $4`,
      [String(name), cleanEmail, hashed, Number(user.id)]
    );
    
    // Generate new session token with only valid JWT fields
    const newToken = signToken({ 
      userId: user.id, 
      email: cleanEmail,
      // Note: Add any additional standard claims as needed
      // but avoid custom claims that aren't in JwtPayload type
    });
    
    // Update session with new token
    await query(
      `UPDATE sessions 
       SET token = $1, expires_at = NOW() + INTERVAL '7 days' 
       WHERE user_id = $2`,
      [newToken, user.id]
    );
    
    // Create response with new token
    const response = NextResponse.json({ 
      success: true, 
      message: 'Registration completed',
      token: newToken
    });
    
    // Set HTTP-only cookie
    response.cookies.set('authToken', newToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    });

    // Add welcome credits (best-effort)
    try {
      await query(
        `INSERT INTO auth_credit_transactions (user_id, type, amount, reason)
         VALUES ($1, 'credit', 10, 'Welcome bonus')
         ON CONFLICT DO NOTHING`,
        [Number(user.id)]
      );
    } catch (e) {
      console.error('Failed to add welcome credits:', e);
    }

    // Send welcome email (best-effort)
    try {
      await sendEmail({
        to: cleanEmail,
        subject: 'Welcome to TruOTP',
        text: `Hi ${String(name)},\n\nWelcome to TruOTP! Your account has been registered successfully.\n\n— Team TruOTP`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>Welcome to TruOTP, ${String(name)}!</h2>
            <p>Your account has been successfully registered and is ready to use.</p>
            <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
            <p>Best regards,<br>The TruOTP Team</p>
          </div>
        `
      });
    } catch (e) {
      console.error('Failed to send welcome email:', e);
    }
    
    // Send greeting message via bot (best-effort)
    try { 
      await sendGreeting(String(user.phone || ''), String(name)); 
    } catch (e) {
      console.error('Failed to send greeting message:', e);
    }
    
    return response;
  } catch (e: any) {
    // eslint-disable-next-line no-console
    console.error('complete-registration error:', e);
    return NextResponse.json({ success: false, message: 'Failed to complete registration' }, { status: 500 });
  }
}
