import { NextRequest, NextResponse } from 'next/server';
import { signToken } from '@/lib/jwt';
import { query } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const hash = url.searchParams.get('hash');
    if (!hash) return new NextResponse('Missing hash', { status: 400 });

    const lrRes = await query<{ id: number; phone: string; isVerified: boolean; expiresAt: string }>(
      `SELECT id, phone, is_verified AS "isVerified", expires_at AS "expiresAt"
       FROM login_requests
       WHERE hash_code = $1
       ORDER BY created_at DESC
       LIMIT 1`,
      [String(hash)]
    );
    const lr = lrRes.rows[0];
    if (!lr) return new NextResponse('Invalid or expired link', { status: 400 });

    const now = new Date();
    const expiresAt = new Date(lr.expiresAt as any);
    if (expiresAt <= now) return new NextResponse('Invalid or expired link', { status: 400 });

    if (!lr.isVerified) {
      await query(`UPDATE login_requests SET is_verified = true, verified_at = NOW() WHERE id = $1`, [lr.id]);
    }

    const requestPhone = String(lr.phone);
    
    // Check if user exists and is not blocked
    const uRes = await query<{ id: number; isBlocked: boolean; email: string | null }>(
      `SELECT id, is_blocked AS "isBlocked", email FROM users WHERE phone = $1 LIMIT 1`,
      [requestPhone]
    );
    
    // If user doesn't exist, redirect to registration page with a message
    if (!uRes.rows[0]) {
      const frontendBase = process.env.FRONTEND_URL || 'http://localhost:3000';
      const u = new URL('/register', frontendBase);
      u.searchParams.set('phone', requestPhone);
      u.searchParams.set('from', 'whatsapp');
      u.searchParams.set('message', 'Please register an account before using WhatsApp login');
      return NextResponse.redirect(u.toString(), { status: 302 });
    }
    
    const user = uRes.rows[0];
    const uid = user.id;
    const isBlocked = Boolean(user.isBlocked);
    
    if (isBlocked) {
      return new NextResponse('Your account is blocked. Please contact support.', { status: 403 });
    }
    
    // Ensure the user has completed registration (has an email and name)
    if (!user.email) {
      const frontendBase = process.env.FRONTEND_URL || 'http://localhost:3000';
      const u = new URL('/complete-registration', frontendBase);
      u.searchParams.set('phone', requestPhone);
      u.searchParams.set('from', 'whatsapp');
      u.searchParams.set('message', 'Please complete your registration before logging in');
      return NextResponse.redirect(u.toString(), { status: 302 });
    }

    const token = signToken({ userId: uid, phone: requestPhone });
    const sessionExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await query(
      `INSERT INTO sessions (user_id, token, expires_at, auth_method)
       VALUES ($1, $2, $3, 'whatsapp')`,
      [uid, token, sessionExpiresAt]
    );

    const frontendBase = process.env.FRONTEND_URL || 'http://localhost:3000';
    const u = new URL('/after-login-page', frontendBase);
    
    // Set the auth token in the session
    const response = NextResponse.redirect(u.toString(), { status: 302 });
    
    // Set the auth token in an HTTP-only cookie
    response.cookies.set('authToken', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    });
    
    return response;
  } catch (e: any) {
    // eslint-disable-next-line no-console
    console.error('whatsapp-verify error:', e);
    return new NextResponse('Internal server error', { status: 500 });
  }
}
