import { NextRequest, NextResponse } from 'next/server';
import { sendEmail } from '@/lib/email';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const noStore = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
  'Pragma': 'no-cache',
  'Expires': '0',
  'Surrogate-Control': 'no-store',
} as const;

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      ...noStore,
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, x-internal-key',
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    const key = req.headers.get('x-internal-key') || '';
    const expected = process.env.BOT_INTERNAL_KEY || 'dev-secret-key';
    if (key !== expected) {
      return NextResponse.json({ success: false, message: 'Forbidden' }, { status: 403, headers: noStore });
    }

    const { to, subject, text, html, from } = await req.json();
    if (!to || !subject) {
      return NextResponse.json({ success: false, message: 'to and subject are required' }, { status: 400, headers: noStore });
    }

    const fromAddr = from || process.env.EMAIL_FROM || 'noreply@truotp.com';
    const ok = await sendEmail({ to: String(to), subject: String(subject), text: text ? String(text) : undefined, html: html ? String(html) : undefined, from: fromAddr });
    if (!ok) return NextResponse.json({ success: false, message: 'Email provider not configured or failed' }, { status: 500, headers: noStore });

    return NextResponse.json({ success: true }, { headers: noStore });
  } catch (e: any) {
    // eslint-disable-next-line no-console
    console.error('bot/send-email error:', e);
    return NextResponse.json({ success: false, message: 'Failed to send email' }, { status: 500, headers: noStore });
  }
}
