import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth } from '@/lib/authApi';
import { trackSession } from '@/lib/sessionTracker';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { user } = await requireAuth(req);
    const userId = user.id;
    
    // Update lastSeen for this request context
    await trackSession(userId, req);

    const { searchParams } = new URL(req.url);
    const limit = Math.min(200, Math.max(1, Number(searchParams.get('limit') || 50)));

    const { rows } = await query(
      `SELECT id, user_id AS "userId", ip, user_agent AS "userAgent", device_info AS "deviceInfo",
              created_at AS "createdAt", last_seen AS "lastSeen"
       FROM prisma_sessions
       WHERE user_id = $1
       ORDER BY last_seen DESC, created_at DESC
       LIMIT $2`,
      [userId, limit]
    );
    return NextResponse.json(
      { success: true, data: rows },
      { 
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      }
    );
  } catch (e: any) {
    console.error('Sessions API Error:', e);
    
    const status = 500;
    const message = e.message || 'Failed to fetch sessions';
    
    return NextResponse.json(
      { 
        success: false, 
        message,
        code: e.code
      }, 
      { 
        status,
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      }
    );
  }
}
