import { NextRequest, NextResponse } from 'next/server';
import { requireUser, getClientIp, getUserAgent } from '@/lib/authHelpers';
import { requireAuth } from '@/lib/authApi';
import { trackSession } from '@/lib/sessionTracker';
import { sendEmail } from '@/lib/email';
import { parseUserAgent } from '@/lib/userAgentParser';
import { getLocationFromIp } from '@/lib/ipLocation';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    let user: any | null = null;
    let method: 'session' | 'token' = 'session';

    // Try NextAuth session first
    try {
      const res = await requireUser();
      user = res.user;
      method = 'session';
    } catch (e) {
      // If not authed by session, try Bearer token (legacy JWT)
      try {
        const res2 = await requireAuth(req as any);
        user = res2.user;
        method = 'token';
      } catch {
        // fall through, will return skipped below
      }
    }

    if (!user) {
      // Don't block the flow if auth context isn't ready yet
      return NextResponse.json({ success: true, skipped: true });
    }

    // Record active session
    await trackSession(user.id, req);

    // Send login alert via email
    const email = user.email as string | null;
    if (email) {
      const ip = getClientIp(req) || 'unknown IP';
      const ua = getUserAgent(req) || 'unknown device';
      const ts = new Date().toLocaleString('en-IN', { 
        timeZone: 'Asia/Kolkata',
        dateStyle: 'full',
        timeStyle: 'long'
      });
      
      const deviceInfo = parseUserAgent(ua);
      const location = await getLocationFromIp(ip);
      
      const subject = 'New login to your TruOTP account';
      const text = `
New Login Alert
----------------
Time: ${ts}
Device: ${deviceInfo.device || 'Unknown device'}
Browser: ${deviceInfo.browser || 'Unknown browser'}
OS: ${deviceInfo.os || 'Unknown OS'}
Location: ${location || 'Unknown location'}
IP Address: ${ip}

If this wasn't you, please secure your account immediately by changing your password and revoking any suspicious sessions from your account settings.

Best regards,
TruOTP Security Team
      `;

      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
          <h2 style="color: #1a56db;">New Login Alert</h2>
          <p>We detected a new login to your TruOTP account:</p>
          
          <div style="background: #f9fafb; border-radius: 8px; padding: 16px; margin: 16px 0;">
            <p><strong>Time:</strong> ${ts}</p>
            <p><strong>Device:</strong> ${deviceInfo.device || 'Unknown device'}</p>
            <p><strong>Browser:</strong> ${deviceInfo.browser || 'Unknown browser'}</p>
            <p><strong>OS:</strong> ${deviceInfo.os || 'Unknown OS'}</p>
            <p><strong>Location:</strong> ${location || 'Unknown location'}</p>
            <p><strong>IP Address:</strong> <code>${ip}</code></p>
          </div>
          
          <p>If this wasn't you, please take these steps immediately:</p>
          <ol>
            <li>Change your password</li>
            <li>Review active sessions in your account settings</li>
            <li>Revoke any suspicious sessions</li>
          </ol>
          
          <div style="margin: 24px 0; text-align: center;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/settings/security" 
               style="display: inline-block; background: #1a56db; color: white; 
                      padding: 12px 24px; border-radius: 6px; text-decoration: none;">
              Review Account Security
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 16px;">
            For security reasons, do not forward this email. If you have any questions, please contact our support team.
          </p>
          
          <p style="margin-top: 24px;">
            Best regards,<br>
            <strong>TruOTP Security Team</strong>
          </p>
        </div>
      `;

      try { 
        await sendEmail({ 
          to: email, 
          subject,
          text: text.trim(),
          html
        });
      } catch (error) {
        console.error('Failed to send login alert email:', error);
      }
    }

    return NextResponse.json({ success: true, alerted: Boolean(user.email) });
  } catch (e: any) {
    // If the session isn't ready yet, don't fail the login flow; just return success.
    if (e instanceof Response) {
      const status = (e as Response).status;
      if (status === 401 || status === 403) {
        return NextResponse.json({ success: true, skipped: true });
      }
      return e;
    }
    console.error('Error in track-login:', e);
    return NextResponse.json({ success: false, message: 'Failed to track login' }, { status: 500 });
  }
}
