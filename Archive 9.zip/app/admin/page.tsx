"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { signOut, useSession } from 'next-auth/react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Activity, TrendingUp, DollarSign, Shield,
  AlertCircle, CheckCircle, Clock, Database, Server,
  Cpu, HardDrive, Wifi, RefreshCw, Download, Upload,
  Mail, Phone, MessageSquare, FileText, Settings,
  Search, Filter, ChevronDown, ChevronRight, MoreVertical,
  Eye, Edit, Trash2, Ban, UserCheck, Lock, Unlock,
  Send, Archive, FolderOpen, Globe, Zap, BarChart3
} from 'lucide-react';

type AdminSummary = {
  totalUsers: number;
  sessionsByMethod: { auth_method: string; count: number }[];
  sessionsLast24h: { auth_method: string; count: number }[];
  timestamp: string;
  totalTickets?: number;
};

type AdminUser = {
  id: number;
  phone: string | null;
  email: string | null;
  name: string | null;
  created_at: string;
  role: string;
  isBlocked?: boolean;
  totalAuthCredits: number;
  last_login_at: string | null;
};

type SupportTicket = {
  id: number;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
  user: { id: number; email: string | null; name: string | null; phone: string | null };
};

type AdminAuthLog = {
  id: number;
  user_id: number;
  phone: string | null;
  email: string | null;
  name: string | null;
  auth_method: string | null;
  created_at: string;
  expires_at: string;
};

// Additional admin dataset types
type ContactMessage = {
  id: number;
  email: string;
  phone: string;
  message: string;
  createdAt: string;
};

type LoginRequest = {
  id: number;
  phone: string;
  hash: string;
  verified: boolean;
  expiresAt: string;
  createdAt: string;
  verifiedAt: string | null;
  lastFailedReason: string | null;
  lastFailedAt: string | null;
};

type OtpRequest = {
  id: number;
  phone: string;
  type: string;
  consumed: boolean;
  expiresAt: string;
  createdAt: string;
  verifiedAt: string | null;
};

type SessionRec = {
  id: number;
  userId: number;
  token: string;
  expiresAt: string;
  authMethod: string | null;
  createdAt: string;
};

type PrismaSessionRec = {
  id: number;
  userId: number;
  ip: string | null;
  userAgent: string | null;
  deviceInfo: any;
  createdAt: string;
  lastSeen: string;
};

type ApiResponse<T> = { success: boolean; data: T; message?: string };

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring" as const,
      stiffness: 100
    }
  }
};

export default function AdminPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'operations' | 'analytics' | 'settings'>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [adminLoginVerified, setAdminLoginVerified] = useState(false);

  const [summary, setSummary] = useState<AdminSummary | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [authLogs, setAuthLogs] = useState<AdminAuthLog[]>([]); // will hold transactions now
  const [usageLogs, setUsageLogs] = useState<AdminAuthLog[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [ticketsTotal, setTicketsTotal] = useState<number>(0);
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>([]);
  const [loginRequests, setLoginRequests] = useState<LoginRequest[]>([]);
  const [otpRequests, setOtpRequests] = useState<OtpRequest[]>([]);
  const [sessions, setSessions] = useState<SessionRec[]>([]);
  const [prismaSessions, setPrismaSessions] = useState<PrismaSessionRec[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [query, setQuery] = useState("");
  const [roleSavingId, setRoleSavingId] = useState<number | null>(null);
  const [blockSavingId, setBlockSavingId] = useState<number | null>(null);
  const [closingTicketId, setClosingTicketId] = useState<number | null>(null);
  const [ticketStatus, setTicketStatus] = useState<'All' | 'Open' | 'Closed'>('All');
  const [maintLoading, setMaintLoading] = useState(false);
  const [maintResult, setMaintResult] = useState<any>(null);

  const authHeaders = (): HeadersInit => ({
    "Content-Type": "application/json"
  });

  const loadAll = async () => {
    setLoading(true);
    setError("");
    try {
      const ticketsUrl = `/api/admin/tickets${ticketStatus && ticketStatus !== 'All' ? `?status=${encodeURIComponent(ticketStatus)}` : ''}`;
      const [sRes, uRes, lRes, ulRes, tRes, cmRes, lrRes, orRes, ssRes, psRes] = await Promise.all([
        fetch(`/api/admin/summary`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/users${query ? `?q=${encodeURIComponent(query)}` : ""}`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/transactions`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/usage-logs`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(ticketsUrl, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/contact-messages`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/login-requests`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/otp-requests`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/sessions`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
        fetch(`/api/admin/prisma-sessions`, { headers: authHeaders(), credentials: 'same-origin', cache: 'no-store' }),
      ]);

      // Handle 401/403 explicitly
      if ([sRes, uRes, lRes, ulRes, tRes, cmRes, lrRes, orRes, ssRes, psRes].some(r => r.status === 401)) {
        setError("Unauthorized. Please sign in.");
        router.replace('/admin-login');
        return;
      }
      if ([sRes, uRes, lRes, ulRes, tRes, cmRes, lrRes, orRes, ssRes, psRes].some(r => r.status === 403)) {
        setError("Forbidden. Your account does not have admin access.");
        router.replace('/admin-login');
        return;
      }

      if (!sRes.ok) throw new Error(`Summary failed (${sRes.status})`);
      if (!uRes.ok) throw new Error(`Users failed (${uRes.status})`);
      if (!lRes.ok) throw new Error(`Transactions failed (${lRes.status})`);
      if (!ulRes.ok) throw new Error(`Usage logs failed (${ulRes.status})`);
      if (!tRes.ok) throw new Error(`Tickets failed (${tRes.status})`);
      if (!cmRes.ok) throw new Error(`Contact messages failed (${cmRes.status})`);
      if (!lrRes.ok) throw new Error(`Login requests failed (${lrRes.status})`);
      if (!orRes.ok) throw new Error(`OTP requests failed (${orRes.status})`);
      if (!ssRes.ok) throw new Error(`Sessions failed (${ssRes.status})`);
      if (!psRes.ok) throw new Error(`Prisma sessions failed (${psRes.status})`);

      const sJson: ApiResponse<AdminSummary> = await sRes.json();
      const uJson: ApiResponse<AdminUser[]> = await uRes.json();
      const lJson: ApiResponse<any> = await lRes.json();
      const ulJson: ApiResponse<AdminAuthLog[]> = await ulRes.json();
      const tJson: ApiResponse<{ tickets: SupportTicket[]; totalCount: number; byStatus: { status: string; _count: { _all: number } }[] }>
        = await tRes.json();
      const cmJson: ApiResponse<ContactMessage[]> = await cmRes.json();
      const lrJson: ApiResponse<LoginRequest[]> = await lrRes.json();
      const orJson: ApiResponse<OtpRequest[]> = await orRes.json();
      const ssJson: ApiResponse<SessionRec[]> = await ssRes.json();
      const psJson: ApiResponse<PrismaSessionRec[]> = await psRes.json();
      if (!sJson.success) throw new Error(sJson.message || "Summary error");
      if (!uJson.success) throw new Error(uJson.message || "Users error");
      if (!lJson.success) throw new Error(lJson.message || "Transactions error");
      if (!ulJson.success) throw new Error(ulJson.message || "Usage logs error");
      if (!tJson.success) throw new Error(tJson.message || "Tickets error");
      if (!cmJson.success) throw new Error(cmJson.message || "Contact messages error");
      if (!lrJson.success) throw new Error(lrJson.message || "Login requests error");
      if (!orJson.success) throw new Error(orJson.message || "OTP requests error");
      if (!ssJson.success) throw new Error(ssJson.message || "Sessions error");
      if (!psJson.success) throw new Error(psJson.message || "Prisma sessions error");
      setSummary(sJson.data);
      setUsers(uJson.data);
      setAuthLogs(lJson.data);
      setUsageLogs(ulJson.data);
      setTickets(tJson.data.tickets);
      setTicketsTotal(tJson.data.totalCount);
      setContactMessages(cmJson.data);
      setLoginRequests(lrJson.data);
      setOtpRequests(orJson.data);
      setSessions(ssJson.data);
      setPrismaSessions(psJson.data);
    } catch (e: any) {
      setError(e?.message || "Failed to load admin data");
    } finally {
      setLoading(false);
    }
  };

  const toggleBlock = async (id: number, isBlocked: boolean) => {
    setBlockSavingId(id);
    setError("");
    try {
      const res = await fetch(`/api/admin/users/${id}/block`, {
        method: 'PATCH',
        headers: authHeaders(),
        credentials: 'same-origin',
        cache: 'no-store',
        body: JSON.stringify({ isBlocked }),
      });
      if (res.status === 401) {
        setError("Unauthorized. Please sign in again.");
        router.replace("/admin-login");
        return;
      }
      if (res.status === 403) {
        setError("Forbidden. Your account does not have admin access.");
        return;
      }
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`Failed to update block status (${res.status}): ${t}`);
      }
      const json: ApiResponse<AdminUser> = await res.json();
      if (!json.success) throw new Error(json.message || 'Update failed');
      setUsers((prev) => prev.map(u => u.id === id ? { ...u, isBlocked: json.data.isBlocked } : u));
    } catch (e: any) {
      setError(e?.message || 'Failed to update block status');
    } finally {
      setBlockSavingId(null);
    }
  };

  const changeUserRole = async (id: number, role: 'user' | 'admin') => {
    setRoleSavingId(id);
    setError("");
    try {
      const res = await fetch(`/api/admin/users/${id}/role`, {
        method: 'PATCH',
        headers: authHeaders(),
        credentials: 'same-origin',
        cache: 'no-store',
        body: JSON.stringify({ role })
      });
      if (res.status === 401) {
        setError("Unauthorized. Please sign in again.");
        router.replace("/admin-login");
        return;
      }
      if (res.status === 403) {
        setError("Forbidden. Your account does not have admin access.");
        return;
      }
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`Failed to update role (${res.status}): ${t}`);
      }
      const json: ApiResponse<AdminUser> = await res.json();
      if (!json.success) throw new Error(json.message || 'Update failed');
      // Update local state
      setUsers((prev) => prev.map(u => u.id === id ? { ...u, role: json.data.role } : u));
    } catch (e: any) {
      setError(e?.message || 'Failed to update role');
    } finally {
      setRoleSavingId(null);
    }
  };

  const closeTicket = async (id: number) => {
    setClosingTicketId(id);
    setError("");
    try {
      const res = await fetch(`/api/admin/tickets/${id}/close`, {
        method: 'PATCH',
        headers: authHeaders(),
        credentials: 'same-origin',
        cache: 'no-store',
      });
      if (res.status === 401) {
        setError("Unauthorized. Please sign in again.");
        router.replace("/admin-login");
        return;
      }
      if (res.status === 403) {
        setError("Forbidden. Your account does not have admin access.");
        return;
      }
      if (!res.ok) {
        const t = await res.text();
        throw new Error(`Failed to close ticket (${res.status}): ${t}`);
      }
      const json: ApiResponse<SupportTicket> = await res.json();
      if (!json.success) throw new Error(json.message || 'Close failed');
      setTickets((prev) => prev.map((t) => t.id === id ? { ...t, status: 'Closed' } : t));
    } catch (e: any) {
      setError(e?.message || 'Failed to close ticket');
    } finally {
      setClosingTicketId(null);
    }
  };

  useEffect(() => {
    if (status === 'loading') return;
    
    const loginFlag = sessionStorage.getItem('admin_login_verified');
    
    if (!loginFlag) {
      router.replace('/admin-login');
      return;
    }
    
    setAdminLoginVerified(true);
    
    if (status === 'unauthenticated') {
      sessionStorage.removeItem('admin_login_verified');
      router.replace('/admin-login');
      return;
    }
    
    if (session && (session.user as any)?.role !== 'admin') {
      sessionStorage.removeItem('admin_login_verified');
      router.replace('/admin-login');
      return;
    }
    
    if (status === 'authenticated' && session) {
      loadAll();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, session]);

  useEffect(() => {
    if (adminLoginVerified) loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ticketStatus]);

  useEffect(() => {
    const onFocus = () => {
      if (adminLoginVerified) loadAll();
    };
    const onPageShow = (e: PageTransitionEvent) => {
      if (adminLoginVerified) loadAll();
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible' && adminLoginVerified) {
        loadAll();
      }
    };
    window.addEventListener('focus', onFocus);
    window.addEventListener('pageshow', onPageShow as any);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('pageshow', onPageShow as any);
      document.removeEventListener('visibilitychange', onVisibility);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [adminLoginVerified]);

  if (status === 'loading' || !adminLoginVerified) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-white/60">Checking authentication...</div>
      </div>
    );
  }

  if (status === 'unauthenticated' || !session || (session.user as any)?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-white/60">Redirecting to login...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/10 to-slate-900 text-white">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 -left-4 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute top-0 -right-4 w-72 h-72 bg-yellow-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
      </div>

      {/* Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 100 }}
        className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-xl border-b border-white/10"
      >
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.h1 
                className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
                whileHover={{ scale: 1.05 }}
              >
                Admin Control Center
              </motion.h1>
              <div className="flex gap-2">
                <motion.div 
                  whileHover={{ scale: 1.1 }}
                  className="flex items-center gap-1 px-3 py-1 rounded-full bg-green-500/20 border border-green-500/30"
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-green-300">System Online</span>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.1 }}
                  className="flex items-center gap-1 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30"
                >
                  <Activity className="w-3 h-3 text-blue-300" />
                  <span className="text-xs text-blue-300">{users.length} Users</span>
                </motion.div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="relative"
              >
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Search users, tickets..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-sm focus:outline-none focus:border-blue-400 focus:bg-white/15 transition-all w-64"
                />
              </motion.div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={loadAll}
                disabled={loading}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 transition-all shadow-lg hover:shadow-blue-500/25"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  sessionStorage.removeItem('admin_login_verified');
                  signOut({ callbackUrl: '/admin-login' });
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 transition-all"
              >
                <Lock className="w-4 h-4" />
                Logout
              </motion.button>
            </div>
          </div>
          
          {/* Navigation Tabs */}
          <div className="flex gap-1 mt-4">
            {['overview', 'users', 'operations', 'analytics', 'settings'].map((tab) => (
              <motion.button
                key={tab}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-2 rounded-t-xl capitalize transition-all ${
                  activeTab === tab
                    ? 'bg-white/10 border-b-2 border-blue-400 text-white'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.header>

      <main className="p-6 space-y-6">
        {error && (
          <div className="bg-red-600/20 border border-red-600/40 rounded p-4 text-red-200">
            {error}
          </div>
        )}
        {loading && <div className="text-white/60">Loading...</div>}
        {!loading && (
          <>
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              {/* Key Metrics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <motion.div
                  variants={itemVariants}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border border-blue-500/30 rounded-2xl p-6 backdrop-blur-sm shadow-xl relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-400/10 to-transparent"></div>
                  <div className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <Users className="w-8 h-8 text-blue-400" />
                      <span className="text-xs px-2 py-1 bg-blue-500/20 rounded-full text-blue-300">Total</span>
                    </div>
                    <div className="text-white/70 text-sm mb-1">Total Users</div>
                    <div className="text-3xl font-bold">{summary?.totalUsers ?? users.length}</div>
                    <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-blue-400 to-blue-600"
                        initial={{ width: 0 }}
                        animate={{ width: '75%' }}
                        transition={{ duration: 1, delay: 0.3 }}
                      />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-gradient-to-br from-green-600/20 to-green-800/20 border border-green-500/30 rounded-2xl p-6 backdrop-blur-sm shadow-xl relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-green-400/10 to-transparent"></div>
                  <div className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <FileText className="w-8 h-8 text-green-400" />
                      <span className="text-xs px-2 py-1 bg-green-500/20 rounded-full text-green-300">Support</span>
                    </div>
                    <div className="text-white/70 text-sm mb-1">Total Tickets</div>
                    <div className="text-3xl font-bold">{ticketsTotal}</div>
                    <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-green-400 to-green-600"
                        initial={{ width: 0 }}
                        animate={{ width: '60%' }}
                        transition={{ duration: 1, delay: 0.4 }}
                      />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 border border-purple-500/30 rounded-2xl p-6 backdrop-blur-sm shadow-xl relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-400/10 to-transparent"></div>
                  <div className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <MessageSquare className="w-8 h-8 text-purple-400" />
                      <span className="text-xs px-2 py-1 bg-purple-500/20 rounded-full text-purple-300">Inquiries</span>
                    </div>
                    <div className="text-white/70 text-sm mb-1">Contact Messages</div>
                    <div className="text-3xl font-bold">{contactMessages.length}</div>
                    <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-purple-400 to-purple-600"
                        initial={{ width: 0 }}
                        animate={{ width: '45%' }}
                        transition={{ duration: 1, delay: 0.5 }}
                      />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-gradient-to-br from-orange-600/20 to-orange-800/20 border border-orange-500/30 rounded-2xl p-6 backdrop-blur-sm shadow-xl relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-orange-400/10 to-transparent"></div>
                  <div className="relative">
                    <div className="flex items-center justify-between mb-4">
                      <Activity className="w-8 h-8 text-orange-400" />
                      <span className="text-xs px-2 py-1 bg-orange-500/20 rounded-full text-orange-300">Live</span>
                    </div>
                    <div className="text-white/70 text-sm mb-1">Active Sessions</div>
                    <div className="text-3xl font-bold">{sessions.length}</div>
                    <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-gradient-to-r from-orange-400 to-orange-600"
                        initial={{ width: 0 }}
                        animate={{ width: '85%' }}
                        transition={{ duration: 1, delay: 0.6 }}
                      />
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <motion.div variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <h3 className="text-lg font-semibold mb-3 text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    Recent Activity
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Login Requests</span>
                      <span className="font-semibold text-blue-400">{loginRequests.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">OTP Requests</span>
                      <span className="font-semibold text-green-400">{otpRequests.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Transactions</span>
                      <span className="font-semibold text-purple-400">{authLogs.length}</span>
                    </div>
                  </div>
                </motion.div>

                <motion.div variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <h3 className="text-lg font-semibold mb-3 text-white flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-yellow-400" />
                    Support Status
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Open Tickets</span>
                      <span className="font-semibold text-yellow-400">{tickets.filter(t => t.status.toLowerCase() !== 'closed').length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Closed Tickets</span>
                      <span className="font-semibold text-green-400">{tickets.filter(t => t.status.toLowerCase() === 'closed').length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Pending Messages</span>
                      <span className="font-semibold text-purple-400">{contactMessages.length}</span>
                    </div>
                  </div>
                </motion.div>

                <motion.div variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl p-4 backdrop-blur-sm">
                  <h3 className="text-lg font-semibold mb-3 text-white flex items-center gap-2">
                    <Server className="w-5 h-5 text-green-400" />
                    System Health
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">Database</span>
                      <span className="font-semibold text-green-400 flex items-center gap-1">
                        <CheckCircle className="w-4 h-4" /> Online
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">API</span>
                      <span className="font-semibold text-green-400 flex items-center gap-1">
                        <CheckCircle className="w-4 h-4" /> Healthy
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/70">App Sessions</span>
                      <span className="font-semibold text-blue-400">{prismaSessions.length}</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
            )}

            {/* USERS TAB */}
            {activeTab === 'users' && (
            <motion.div
              key="users"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              {/* Users Management */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
              <div className="p-4 flex items-center justify-between border-b border-white/10">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-400" />
                  User Management
                </h2>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                    <input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search by name or email"
                      className="pl-9 pr-4 py-2 rounded-lg bg-white/10 border border-white/20 outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={loadAll}
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 transition-all flex items-center gap-2"
                  >
                    <Search className="w-4 h-4" />
                    Search
                  </motion.button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-2 px-3">ID</th>
                      <th className="text-left py-2 px-3">Email</th>
                      <th className="text-left py-2 px-3">Name</th>
                      <th className="text-left py-2 px-3">Credits</th>
                      <th className="text-left py-2 px-3">Role</th>
                      <th className="text-left py-2 px-3">Status</th>
                      <th className="text-left py-2 px-3">Actions</th>
                      <th className="text-left py-2 px-3">Last Login</th>
                      <th className="text-left py-2 px-3">Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="text-center text-white/60 py-6">No users</td>
                      </tr>
                    ) : (
                      users.map((u) => (
                        <tr key={u.id} className="border-b border-white/10 hover:bg-white/5">
                          <td className="py-2 px-3">{u.id}</td>
                          <td className="py-2 px-3">{u.email || '—'}</td>
                          <td className="py-2 px-3">{u.name || '—'}</td>
                          <td className="py-2 px-3">{u.totalAuthCredits}</td>
                          <td className="py-2 px-3">
                            <select
                              value={(u.role || 'user').toLowerCase()}
                              onChange={(e) => changeUserRole(u.id, e.target.value as 'user' | 'admin')}
                              disabled={roleSavingId === u.id || loading}
                              className="bg-white/10 border border-white/20 rounded px-2 py-1 outline-none focus:ring-2 focus:ring-white/30"
                            >
                              <option value="user">user</option>
                              <option value="admin">admin</option>
                            </select>
                          </td>
                          <td className="py-2 px-3">
                            {u.isBlocked ? (
                              <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-red-600/20 border border-red-600/40 text-red-200">Blocked</span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-1 rounded text-xs bg-green-600/20 border border-green-600/40 text-green-200">Active</span>
                            )}
                          </td>
                          <td className="py-2 px-3">
                            <button
                              onClick={() => toggleBlock(u.id, !u.isBlocked)}
                              disabled={blockSavingId === u.id || loading}
                              className={`px-3 py-1 rounded ${u.isBlocked ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'} disabled:opacity-50`}
                            >
                              {u.isBlocked ? 'Unblock' : 'Block'}
                            </button>
                          </td>
                          <td className="py-2 px-3">{u.last_login_at || '—'}</td>
                          <td className="py-2 px-3">{u.created_at}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              </motion.section>
            </motion.div>
            )}

            {/* OPERATIONS TAB - Support & Customer Service */}
            {activeTab === 'operations' && (
            <motion.div
              key="operations"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              {/* Support Tickets */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
              <div className="p-4 flex items-center justify-between">
                <h2 className="text-lg font-medium">Recent Transactions</h2>
                <div className="text-sm text-white/60">Latest 200</div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-2 px-3">ID</th>
                      <th className="text-left py-2 px-3">User</th>
                      <th className="text-left py-2 px-3">Package</th>
                      <th className="text-left py-2 px-3">Status</th>
                      <th className="text-left py-2 px-3">Credits</th>
                      <th className="text-left py-2 px-3">Method</th>
                      <th className="text-left py-2 px-3">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(authLogs) && authLogs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center text-white/60 py-6">No transactions</td>
                      </tr>
                    ) : (
                      (authLogs as any[]).map((tx: any) => (
                        <tr key={tx.id} className="border-b border-white/10 hover:bg-white/5">
                          <td className="py-2 px-3">{tx.id}</td>
                          <td className="py-2 px-3">{tx.user?.email || tx.user?.id}</td>
                          <td className="py-2 px-3">{tx.package?.name || '—'}</td>
                          <td className="py-2 px-3 capitalize">{tx.status}</td>
                          <td className="py-2 px-3">{tx.creditsPurchased}</td>
                          <td className="py-2 px-3">{tx.method}</td>
                          <td className="py-2 px-3">{tx.timestamp}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              </motion.section>

              {/* Support Tickets */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
              <div className="p-4 flex items-center justify-between border-b border-white/10">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <FileText className="w-5 h-5 text-green-400" />
                  Support Tickets
                </h2>
                <div className="flex items-center gap-3">
                  <label htmlFor="ticketStatus" className="text-sm text-white/70">Status</label>
                  <select
                    id="ticketStatus"
                    value={ticketStatus}
                    onChange={(e) => setTicketStatus(e.target.value as 'All' | 'Open' | 'Closed')}
                    className="bg-white/10 border border-white/20 rounded px-2 py-1 outline-none focus:ring-2 focus:ring-white/30"
                  >
                    <option value="All">All</option>
                    <option value="Open">Open</option>
                    <option value="Closed">Closed</option>
                  </select>
                  <div className="text-sm text-white/60">Total: {ticketsTotal}</div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-2 px-3">ID</th>
                      <th className="text-left py-2 px-3">Subject</th>
                      <th className="text-left py-2 px-3">Description</th>
                      <th className="text-left py-2 px-3">User</th>
                      <th className="text-left py-2 px-3">Phone</th>
                      <th className="text-left py-2 px-3">Status</th>
                      <th className="text-left py-2 px-3">Created</th>
                      <th className="text-left py-2 px-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tickets.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="text-center text-white/60 py-6">No tickets</td>
                      </tr>
                    ) : (
                      tickets.map((t) => (
                        <tr key={t.id} className="border-b border-white/10 hover:bg-white/5">
                          <td className="py-2 px-3">{t.id}</td>
                          <td className="py-2 px-3">{t.subject}</td>
                          <td className="py-2 px-3 max-w-[360px] truncate" title={t.message}>{t.message}</td>
                          <td className="py-2 px-3">{t.user?.email || t.user?.name || t.user?.id}</td>
                          <td className="py-2 px-3">{t.user?.phone || '—'}</td>
                          <td className="py-2 px-3">{t.status}</td>
                          <td className="py-2 px-3">{t.createdAt}</td>
                          <td className="py-2 px-3">
                            {String(t.status).toLowerCase() !== 'closed' ? (
                              <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={() => closeTicket(t.id)}
                                disabled={closingTicketId === t.id || loading}
                                className="px-3 py-1 rounded-lg bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50 transition-all flex items-center gap-1"
                                title="Mark as Closed"
                              >
                                <CheckCircle className="w-3 h-3" />
                                Close
                              </motion.button>
                            ) : (
                              '—'
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              </motion.section>
            </motion.div>
            )}

            {/* ANALYTICS TAB - Logs & Sessions */}
            {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              {/* Usage Logs */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
                <div className="p-4 flex items-center justify-between border-b border-white/10">
                  <h2 className="text-lg font-semibold flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-400" />
                    Usage Logs
                  </h2>
                  <div className="text-sm text-white/60">Latest 200</div>
                </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-2 px-3">ID</th>
                      <th className="text-left py-2 px-3">User</th>
                      <th className="text-left py-2 px-3">Type</th>
                      <th className="text-left py-2 px-3">Amount</th>
                      <th className="text-left py-2 px-3">Reason</th>
                      <th className="text-left py-2 px-3">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(usageLogs) && usageLogs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center text-white/60 py-6">No usage logs</td>
                      </tr>
                    ) : (
                      (usageLogs as any[]).map((log: any) => (
                        <tr key={log.id} className="border-b border-white/10 hover:bg-white/5">
                          <td className="py-2 px-3">{log.id}</td>
                          <td className="py-2 px-3">{log.user?.email || log.userId}</td>
                          <td className="py-2 px-3 capitalize">{log.type}</td>
                          <td className="py-2 px-3">{log.amount}</td>
                          <td className="py-2 px-3">{log.reason}</td>
                          <td className="py-2 px-3">{log.timestamp}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              </motion.section>

              {/* Auth Sessions */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
              <div className="p-4 flex items-center justify-between">
                <h2 className="text-lg font-medium">Recent Transactions</h2>
                <div className="text-sm text-white/60">Latest 200</div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/20">
                      <th className="text-left py-2 px-3">ID</th>
                      <th className="text-left py-2 px-3">User</th>
                      <th className="text-left py-2 px-3">Package</th>
                      <th className="text-left py-2 px-3">Status</th>
                      <th className="text-left py-2 px-3">Credits</th>
                      <th className="text-left py-2 px-3">Method</th>
                      <th className="text-left py-2 px-3">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(authLogs) && authLogs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center text-white/60 py-6">No transactions</td>
                      </tr>
                    ) : (
                      (authLogs as any[]).map((tx: any) => (
                        <tr key={tx.id} className="border-b border-white/10 hover:bg-white/5">
                          <td className="py-2 px-3">{tx.id}</td>
                          <td className="py-2 px-3">{tx.user?.email || tx.user?.id}</td>
                          <td className="py-2 px-3">{tx.package?.name || '—'}</td>
                          <td className="py-2 px-3 capitalize">{tx.status}</td>
                          <td className="py-2 px-3">{tx.creditsPurchased}</td>
                          <td className="py-2 px-3">{tx.method}</td>
                          <td className="py-2 px-3">{tx.timestamp}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              </motion.section>

              {/* App Sessions */}
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
                <div className="p-4 flex items-center justify-between border-b border-white/10">
                  <h2 className="text-lg font-semibold flex items-center gap-2">
                    <Wifi className="w-5 h-5 text-purple-400" />
                    App Sessions (Activity)
                  </h2>
                  <div className="text-sm text-white/60">Latest 200</div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-white/20">
                        <th className="text-left py-2 px-3">ID</th>
                        <th className="text-left py-2 px-3">User</th>
                        <th className="text-left py-2 px-3">IP</th>
                        <th className="text-left py-2 px-3">User Agent</th>
                        <th className="text-left py-2 px-3">Created</th>
                        <th className="text-left py-2 px-3">Last Seen</th>
                      </tr>
                    </thead>
                    <tbody>
                      {prismaSessions.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="text-center text-white/60 py-6">No app sessions</td>
                        </tr>
                      ) : (
                        prismaSessions.map((s) => (
                          <tr key={s.id} className="border-b border-white/10 hover:bg-white/5 transition-colors">
                            <td className="py-2 px-3">{s.id}</td>
                            <td className="py-2 px-3">{s.userId}</td>
                            <td className="py-2 px-3">{s.ip || '—'}</td>
                            <td className="py-2 px-3 max-w-[360px] truncate" title={s.userAgent || ''}>{s.userAgent || '—'}</td>
                            <td className="py-2 px-3">{s.createdAt}</td>
                            <td className="py-2 px-3">{s.lastSeen}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </motion.section>
            </motion.div>
            )}

            {/* SETTINGS TAB - Maintenance */}
            {activeTab === 'settings' && (
            <motion.div
              key="settings"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              <motion.section variants={itemVariants} className="bg-white/10 border border-white/20 rounded-xl shadow-xl backdrop-blur-sm">
                <div className="p-4 flex items-center justify-between border-b border-white/10">
                  <h2 className="text-lg font-semibold flex items-center gap-2">
                    <Settings className="w-5 h-5 text-yellow-400" />
                    System Maintenance
                  </h2>
                </div>
                <div className="p-4 flex flex-wrap items-center gap-3">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={async () => {
                    setMaintLoading(true);
                    setError("");
                    setMaintResult(null);
                    try {
                      const res = await fetch(`/api/admin/maintenance/normalize-phones`, {
                        method: 'POST',
                        headers: authHeaders(),
                        credentials: 'same-origin',
                        cache: 'no-store',
                        body: JSON.stringify({ dryRun: true })
                      });
                      const json = await res.json();
                      if (!res.ok || !json?.success) throw new Error(json?.message || `Failed (${res.status})`);
                      setMaintResult(json);
                    } catch (e: any) {
                      setError(e?.message || 'Dry run failed');
                    } finally {
                      setMaintLoading(false);
                    }
                  }}
                    disabled={maintLoading}
                    className="px-4 py-2 rounded-lg bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50 transition-all flex items-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    {maintLoading ? 'Running…' : 'Dry Run: Normalize Phones (+91)'}
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={async () => {
                    setMaintLoading(true);
                    setError("");
                    try {
                      const res = await fetch(`/api/admin/maintenance/normalize-phones`, {
                        method: 'POST',
                        headers: authHeaders(),
                        credentials: 'same-origin',
                        cache: 'no-store',
                        body: JSON.stringify({ dryRun: false })
                      });
                      const json = await res.json();
                      if (!res.ok || !json?.success) throw new Error(json?.message || `Failed (${res.status})`);
                      setMaintResult(json);
                      // Reload to refresh users list/summary
                      loadAll();
                    } catch (e: any) {
                      setError(e?.message || 'Normalization failed');
                    } finally {
                      setMaintLoading(false);
                    }
                  }}
                    disabled={maintLoading}
                    className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 disabled:opacity-50 transition-all flex items-center gap-2"
                  >
                    <Zap className="w-4 h-4" />
                    {maintLoading ? 'Running…' : 'Normalize Phones Now'}
                  </motion.button>
                {maintResult && (
                  <div className="text-sm text-white/80">
                    <div>Total Users: {maintResult?.data?.total ?? '—'}</div>
                    <div>To Update: {maintResult?.data?.toUpdate ?? '—'}</div>
                    {typeof maintResult?.dryRun !== 'undefined' && (
                      <div>Dry Run: {String(maintResult.dryRun)}</div>
                    )}
                  </div>
                  )}
                </div>
              </motion.section>
            </motion.div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
