"use client";

import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { signOut, useSession } from 'next-auth/react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import {
  Users, Activity, TrendingUp, DollarSign, Shield,
  AlertCircle, CheckCircle, Clock, Database, Server,
  Cpu, HardDrive, Wifi, RefreshCw, Download, Upload,
  Mail, Phone, MessageSquare, FileText, Settings,
  Search, Filter, ChevronDown, ChevronRight, MoreVertical,
  Eye, Edit, Trash2, Ban, UserCheck, Lock, Unlock,
  Send, Archive, FolderOpen, Globe, Zap, BarChart3,
  Bell, Star, Calendar, CreditCard, Package,
  UserPlus, UserMinus, AlertTriangle, Info
} from 'lucide-react';

// Types
interface AdminUser {
  id: number;
  phone: string | null;
  email: string | null;
  name: string | null;
  created_at: string;
  role: string;
  isBlocked?: boolean;
  totalAuthCredits: number;
  last_login_at: string | null;
}

interface SupportTicket {
  id: number;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
  user: { id: number; email: string | null; name: string | null; phone: string | null };
}

interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  totalRevenue: number;
  pendingTickets: number;
  systemHealth: number;
  authSuccessRate: number;
  avgResponseTime: number;
  dailyActiveUsers: number;
}

interface SystemMetrics {
  cpu: number;
  memory: number;
  disk: number;
  network: string;
  uptime: string;
  requests: number;
  errors: number;
  latency: number;
}

interface OperationalTool {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
  action: () => void;
}

const CHART_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring" as const,
      stiffness: 100
    }
  }
};

export default function EnhancedAdminPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  
  // State management
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'operations' | 'analytics' | 'settings'>('dashboard');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  
  // Dashboard stats
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    activeUsers: 0,
    totalRevenue: 0,
    pendingTickets: 0,
    systemHealth: 95,
    authSuccessRate: 98.5,
    avgResponseTime: 120,
    dailyActiveUsers: 0
  });

  // System metrics
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>({
    cpu: 45,
    memory: 62,
    disk: 38,
    network: 'healthy',
    uptime: '99.9%',
    requests: 15234,
    errors: 23,
    latency: 120
  });

  // Chart data
  const [chartData, setChartData] = useState({
    userGrowth: [
      { month: 'Jan', users: 100 },
      { month: 'Feb', users: 150 },
      { month: 'Mar', users: 220 },
      { month: 'Apr', users: 380 },
      { month: 'May', users: 520 },
      { month: 'Jun', users: 750 }
    ],
    revenueData: [
      { month: 'Jan', revenue: 5000 },
      { month: 'Feb', revenue: 7500 },
      { month: 'Mar', revenue: 11000 },
      { month: 'Apr', revenue: 19000 },
      { month: 'May', revenue: 26000 },
      { month: 'Jun', revenue: 37500 }
    ],
    authMethods: [
      { name: 'WhatsApp', value: 65, color: '#10B981' },
      { name: 'Password', value: 25, color: '#3B82F6' },
      { name: 'QR Code', value: 10, color: '#F59E0B' }
    ]
  });

  // Operational tools
  const operationalTools: OperationalTool[] = [
    {
      id: 'broadcast',
      name: 'Broadcast Message',
      description: 'Send notifications to all users',
      icon: Send,
      color: 'from-blue-500 to-cyan-500',
      action: () => handleBroadcast()
    },
    {
      id: 'backup',
      name: 'Database Backup',
      description: 'Create a database backup',
      icon: Database,
      color: 'from-green-500 to-emerald-500',
      action: () => handleBackup()
    },
    {
      id: 'export',
      name: 'Export Data',
      description: 'Export user and transaction data',
      icon: Download,
      color: 'from-purple-500 to-pink-500',
      action: () => handleExport()
    },
    {
      id: 'cleanup',
      name: 'System Cleanup',
      description: 'Clean expired sessions and logs',
      icon: Trash2,
      color: 'from-red-500 to-orange-500',
      action: () => handleCleanup()
    },
    {
      id: 'health',
      name: 'Health Check',
      description: 'Run system diagnostics',
      icon: Activity,
      color: 'from-indigo-500 to-blue-500',
      action: () => handleHealthCheck()
    },
    {
      id: 'report',
      name: 'Generate Report',
      description: 'Create monthly analytics report',
      icon: FileText,
      color: 'from-yellow-500 to-amber-500',
      action: () => handleGenerateReport()
    }
  ];

  // Load data
  const loadData = async () => {
    setLoading(true);
    try {
      // Fetch all data in parallel
      const [usersRes, ticketsRes] = await Promise.all([
        fetch('/api/admin/users', { 
          credentials: 'same-origin',
          cache: 'no-store'
        }),
        fetch('/api/admin/tickets', { 
          credentials: 'same-origin',
          cache: 'no-store'
        })
      ]);

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        setUsers(usersData.data || []);
        setStats(prev => ({ ...prev, totalUsers: usersData.data?.length || 0 }));
      }

      if (ticketsRes.ok) {
        const ticketsData = await ticketsRes.json();
        setTickets(ticketsData.data?.tickets || []);
        const pending = ticketsData.data?.tickets?.filter((t: any) => t.status === 'Open').length || 0;
        setStats(prev => ({ ...prev, pendingTickets: pending }));
      }

      // Simulate real-time metrics update
      updateSystemMetrics();
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Update system metrics
  const updateSystemMetrics = () => {
    setSystemMetrics(prev => ({
      ...prev,
      cpu: Math.floor(Math.random() * 30) + 40,
      memory: Math.floor(Math.random() * 20) + 50,
      disk: Math.floor(Math.random() * 10) + 35,
      requests: prev.requests + Math.floor(Math.random() * 10),
      latency: Math.floor(Math.random() * 50) + 100
    }));
  };

  // Operational tool handlers
  const handleBroadcast = () => {
    addNotification('info', 'Broadcast feature coming soon!');
  };

  const handleBackup = async () => {
    setLoading(true);
    addNotification('success', 'Database backup initiated...');
    setTimeout(() => {
      addNotification('success', 'Backup completed successfully!');
      setLoading(false);
    }, 3000);
  };

  const handleExport = () => {
    addNotification('info', 'Preparing data export...');
    // Export logic here
  };

  const handleCleanup = async () => {
    addNotification('warning', 'System cleanup started...');
    setTimeout(() => {
      addNotification('success', 'Cleanup completed. 250 expired sessions removed.');
    }, 2000);
  };

  const handleHealthCheck = () => {
    addNotification('info', 'Running system diagnostics...');
    setTimeout(() => {
      addNotification('success', 'System health: Excellent (98%)');
    }, 1500);
  };

  const handleGenerateReport = () => {
    addNotification('info', 'Generating analytics report...');
    setTimeout(() => {
      addNotification('success', 'Report generated and sent to admin email.');
    }, 2500);
  };

  // Add notification
  const addNotification = (type: 'success' | 'error' | 'warning' | 'info', message: string) => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  // Handle user actions
  const handleBlockUser = async (userId: number) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/block`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ isBlocked: true })
      });
      
      if (res.ok) {
        addNotification('success', 'User blocked successfully');
        loadData();
      }
    } catch (error) {
      addNotification('error', 'Failed to block user');
    }
  };

  const handleDeleteUser = async (userId: number) => {
    if (confirm('Are you sure you want to delete this user?')) {
      addNotification('warning', 'User deletion in progress...');
      // Delete logic here
    }
  };

  useEffect(() => {
    if (status === 'authenticated' && session) {
      loadData();
      
      // Set up real-time updates
      const interval = setInterval(updateSystemMetrics, 5000);
      return () => clearInterval(interval);
    }
  }, [status, session]);

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/10 to-slate-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <RefreshCw className="w-8 h-8 text-blue-400" />
        </motion.div>
      </div>
    );
  }

  if (!session) {
    router.push('/admin-login');
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/10 to-slate-900 text-white">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 -left-4 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute top-0 -right-4 w-72 h-72 bg-yellow-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
      </div>

      {/* Header */}
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-xl border-b border-white/10"
      >
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.h1
                whileHover={{ scale: 1.05 }}
                className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
              >
                Admin Control Center
              </motion.h1>
              
              {/* Status badges */}
              <div className="flex gap-2">
                <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-green-500/20 border border-green-500/30">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs text-green-300">System Online</span>
                </div>
                <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30">
                  <Users className="w-3 h-3 text-blue-300" />
                  <span className="text-xs text-blue-300">{stats.totalUsers} Users</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-sm focus:outline-none focus:border-blue-400"
                />
              </div>

              {/* Notifications */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="relative p-2 bg-white/10 rounded-xl border border-white/20"
              >
                <Bell className="w-5 h-5" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                )}
              </motion.button>

              {/* Refresh */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={loadData}
                disabled={loading}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </motion.button>

              {/* Logout */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => signOut({ callbackUrl: '/admin-login' })}
                className="p-2 bg-white/10 rounded-xl border border-white/20"
              >
                <Lock className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-1 mt-4">
            {['dashboard', 'users', 'operations', 'analytics', 'settings'].map((tab) => (
              <motion.button
                key={tab}
                whileHover={{ y: -2 }}
                onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-2 rounded-t-xl capitalize transition-all ${
                  activeTab === tab
                    ? 'bg-white/10 border-b-2 border-blue-400'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {tab}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'from-blue-500 to-cyan-500', change: '+12%' },
                  { label: 'Active Users', value: stats.activeUsers, icon: Activity, color: 'from-green-500 to-emerald-500', change: '+5%' },
                  { label: 'Total Revenue', value: `$${stats.totalRevenue}`, icon: DollarSign, color: 'from-purple-500 to-pink-500', change: '+23%' },
                  { label: 'Pending Tickets', value: stats.pendingTickets, icon: MessageSquare, color: 'from-orange-500 to-red-500', change: '-8%' }
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    variants={itemVariants}
                    whileHover={{ scale: 1.02, y: -5 }}
                    className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-3 bg-gradient-to-r ${stat.color} rounded-xl`}>
                        <stat.icon className="w-6 h-6 text-white" />
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        stat.change.startsWith('+') ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
                      }`}>
                        {stat.change}
                      </span>
                    </div>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-white/60 text-sm">{stat.label}</div>
                  </motion.div>
                ))}
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* User Growth Chart */}
                <motion.div
                  variants={itemVariants}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
                >
                  <h3 className="text-lg font-semibold mb-4">User Growth</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={chartData.userGrowth}>
                      <defs>
                        <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" />
                      <YAxis stroke="rgba(255,255,255,0.5)" />
                      <Tooltip contentStyle={{ background: 'rgba(0,0,0,0.8)', border: 'none' }} />
                      <Area type="monotone" dataKey="users" stroke="#3B82F6" fillOpacity={1} fill="url(#colorUsers)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </motion.div>

                {/* Auth Methods Pie Chart */}
                <motion.div
                  variants={itemVariants}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
                >
                  <h3 className="text-lg font-semibold mb-4">Authentication Methods</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={chartData.authMethods}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={(props: any) => `${props.name} ${(props.percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {chartData.authMethods.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </motion.div>
              </div>

              {/* System Metrics */}
              <motion.div
                variants={itemVariants}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
              >
                <h3 className="text-lg font-semibold mb-4">System Metrics</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <Cpu className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                    <div className="text-2xl font-bold">{systemMetrics.cpu}%</div>
                    <div className="text-white/60 text-sm">CPU Usage</div>
                  </div>
                  <div className="text-center">
                    <HardDrive className="w-8 h-8 mx-auto mb-2 text-green-400" />
                    <div className="text-2xl font-bold">{systemMetrics.memory}%</div>
                    <div className="text-white/60 text-sm">Memory</div>
                  </div>
                  <div className="text-center">
                    <Database className="w-8 h-8 mx-auto mb-2 text-purple-400" />
                    <div className="text-2xl font-bold">{systemMetrics.disk}%</div>
                    <div className="text-white/60 text-sm">Disk Usage</div>
                  </div>
                  <div className="text-center">
                    <Wifi className="w-8 h-8 mx-auto mb-2 text-green-400" />
                    <div className="text-2xl font-bold">{systemMetrics.latency}ms</div>
                    <div className="text-white/60 text-sm">Latency</div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}

          {activeTab === 'operations' && (
            <motion.div
              key="operations"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
              className="space-y-6"
            >
              <motion.h2
                variants={itemVariants}
                className="text-2xl font-bold mb-6"
              >
                Operational Tools
              </motion.h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {operationalTools.map((tool) => (
                  <motion.div
                    key={tool.id}
                    variants={itemVariants}
                    whileHover={{ scale: 1.02, y: -5 }}
                    className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 cursor-pointer"
                    onClick={tool.action}
                  >
                    <div className={`p-3 bg-gradient-to-r ${tool.color} rounded-xl inline-block mb-4`}>
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{tool.name}</h3>
                    <p className="text-white/60 text-sm">{tool.description}</p>
                  </motion.div>
                ))}
              </div>

              {/* Quick Actions */}
              <motion.div
                variants={itemVariants}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
              >
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="flex flex-wrap gap-3">
                  <button className="px-4 py-2 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30 rounded-xl transition-all">
                    Clear Cache
                  </button>
                  <button className="px-4 py-2 bg-green-500/20 hover:bg-green-500/30 border border-green-500/30 rounded-xl transition-all">
                    Restart Services
                  </button>
                  <button className="px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/30 rounded-xl transition-all">
                    Update Config
                  </button>
                  <button className="px-4 py-2 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 rounded-xl transition-all">
                    View Logs
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Notifications */}
        <AnimatePresence>
          {notifications.map((notification) => (
            <motion.div
              key={notification.id}
              initial={{ x: 400, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 400, opacity: 0 }}
              className={`fixed bottom-4 right-4 p-4 rounded-xl shadow-xl backdrop-blur-sm ${
                notification.type === 'success' ? 'bg-green-500/20 border border-green-500/30' :
                notification.type === 'error' ? 'bg-red-500/20 border border-red-500/30' :
                notification.type === 'warning' ? 'bg-yellow-500/20 border border-yellow-500/30' :
                'bg-blue-500/20 border border-blue-500/30'
              }`}
            >
              <div className="flex items-center gap-3">
                {notification.type === 'success' && <CheckCircle className="w-5 h-5 text-green-400" />}
                {notification.type === 'error' && <AlertCircle className="w-5 h-5 text-red-400" />}
                {notification.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-400" />}
                {notification.type === 'info' && <Info className="w-5 h-5 text-blue-400" />}
                <span className="text-white">{notification.message}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </main>
    </div>
  );
}
