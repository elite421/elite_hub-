"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { 
  MetricCard, 
  WelcomeSection, 
  QuickActionCard, 
  AnimatedTable,
  TabNavigation,
  AnimatedLoader,
  FeatureHighlight
} from "@/components/AnimatedDashboard";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import {
  Grid, BarChart3, TrendingUp, Star, Package,
  RotateCcw, Settings, Code, FileText, Phone,
  User, LogOut, Menu, X, ChevronDown, HelpCircle,
  Search, Download, CheckCircle2, XCircle, AlertTriangle,
  Info, CreditCard, Shield, Activity, Zap, Bell,
  Calendar, Clock, Globe, Wifi, Database, Send,
  MessageSquare, UserPlus, Gift, Award, Target
} from "lucide-react";

interface User {
  name: string;
  email: string;
  phone: string;
  authCredit: number;
  isPremium?: boolean;
}

interface Stats {
  totalAuths: number;
  successRate: number;
  creditsUsed: number;
  avgResponseTime: number;
}

export default function EnhancedAfterLoginPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [showNotifications, setShowNotifications] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [stats, setStats] = useState<Stats>({
    totalAuths: 1234,
    successRate: 98.5,
    creditsUsed: 456,
    avgResponseTime: 120
  });

  const [chartData] = useState({
    usage: [
      { day: 'Mon', usage: 45 },
      { day: 'Tue', usage: 52 },
      { day: 'Wed', usage: 38 },
      { day: 'Thu', usage: 65 },
      { day: 'Fri', usage: 48 },
      { day: 'Sat', usage: 35 },
      { day: 'Sun', usage: 42 }
    ],
    authTypes: [
      { name: 'WhatsApp', value: 45, color: '#10B981' },
      { name: 'SMS', value: 30, color: '#3B82F6' },
      { name: 'Email', value: 25, color: '#F59E0B' }
    ]
  });

  const [recentActivity] = useState([
    { id: 1, type: 'auth', status: 'success', time: '2 min ago', description: 'WhatsApp verification completed' },
    { id: 2, type: 'credit', status: 'added', time: '1 hour ago', description: '100 credits added to account' },
    { id: 3, type: 'auth', status: 'success', time: '2 hours ago', description: 'SMS OTP verified' },
    { id: 4, type: 'settings', status: 'updated', time: '5 hours ago', description: 'Profile updated successfully' }
  ]);

  const [notifications] = useState([
    { id: 1, title: 'New Feature!', message: 'WhatsApp Business API now available', time: '1h ago', unread: true },
    { id: 2, title: 'Credit Alert', message: 'Your credits are running low', time: '3h ago', unread: true },
    { id: 3, title: 'System Update', message: 'Maintenance scheduled for tonight', time: '5h ago', unread: false }
  ]);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Grid },
    { id: 'usage', label: 'Usage', icon: BarChart3 },
    { id: 'sessions', label: 'Sessions', icon: Activity, badge: '3' },
    { id: 'transactions', label: 'Transactions', icon: CreditCard },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  useEffect(() => {
    const loadUserData = async () => {
      const token = localStorage.getItem('authToken');
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.data);
        } else {
          router.push('/login');
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUserData();
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <AnimatedLoader />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 text-white">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 -left-4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute top-0 -right-4 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
      </div>

      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            className="fixed left-0 top-0 h-full w-72 bg-slate-900/95 backdrop-blur-xl border-r border-white/10 z-40"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold">Dashboard</h2>
                <button onClick={() => setSidebarOpen(false)}>
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <motion.button
                    key={tab.id}
                    whileHover={{ x: 5 }}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                    {tab.badge && (
                      <span className="ml-auto px-2 py-0.5 text-xs bg-red-500 rounded-full">
                        {tab.badge}
                      </span>
                    )}
                  </motion.button>
                ))}
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="sticky top-0 z-30 bg-slate-900/80 backdrop-blur-xl border-b border-white/10"
      >
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors lg:hidden"
              >
                <Menu className="w-5 h-5" />
              </button>
              
              <motion.h1
                whileHover={{ scale: 1.05 }}
                className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"
              >
                True OTP Dashboard
              </motion.h1>
            </div>

            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="hidden md:block relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-sm focus:outline-none focus:border-blue-400 w-64"
                />
              </div>

              {/* Notifications */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 bg-white/10 rounded-xl border border-white/20"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </motion.button>

              {/* Profile */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="flex items-center gap-3 px-4 py-2 bg-white/10 rounded-xl border border-white/20"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div className="hidden md:block">
                  <div className="text-sm font-medium">{user?.name || 'User'}</div>
                  <div className="text-xs text-white/60">{user?.email}</div>
                </div>
                <button onClick={handleLogout}>
                  <LogOut className="w-4 h-4" />
                </button>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Notifications Dropdown */}
      <AnimatePresence>
        {showNotifications && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute right-6 top-20 w-96 bg-slate-900/95 backdrop-blur-xl border border-white/20 rounded-2xl shadow-xl z-50"
          >
            <div className="p-4 border-b border-white/10">
              <h3 className="font-semibold">Notifications</h3>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {notifications.map((notif) => (
                <motion.div
                  key={notif.id}
                  whileHover={{ backgroundColor: "rgba(255, 255, 255, 0.05)" }}
                  className="p-4 border-b border-white/10 cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 mt-2 rounded-full ${notif.unread ? 'bg-blue-400' : 'bg-white/20'}`} />
                    <div className="flex-1">
                      <div className="font-medium text-sm">{notif.title}</div>
                      <div className="text-white/60 text-xs mt-1">{notif.message}</div>
                      <div className="text-white/40 text-xs mt-2">{notif.time}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="p-6 max-w-7xl mx-auto">
        <WelcomeSection userName={user?.name || 'User'} />

        {/* Tab Navigation (Desktop) */}
        <div className="hidden lg:block mb-8">
          <TabNavigation tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricCard
                  title="Total Authentications"
                  value={stats.totalAuths}
                  change="+12%"
                  icon={Shield}
                  color="from-blue-600/20 to-blue-800/20"
                  delay={0}
                />
                <MetricCard
                  title="Success Rate"
                  value={`${stats.successRate}%`}
                  change="+2.5%"
                  icon={CheckCircle2}
                  color="from-green-600/20 to-green-800/20"
                  delay={0.1}
                />
                <MetricCard
                  title="Credits Used"
                  value={stats.creditsUsed}
                  change="-8%"
                  icon={CreditCard}
                  color="from-purple-600/20 to-purple-800/20"
                  delay={0.2}
                />
                <MetricCard
                  title="Avg Response Time"
                  value={`${stats.avgResponseTime}ms`}
                  change="-15ms"
                  icon={Clock}
                  color="from-orange-600/20 to-orange-800/20"
                  delay={0.3}
                />
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Usage Chart */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 }}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
                >
                  <h3 className="text-lg font-semibold mb-4">Weekly Usage</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={chartData.usage}>
                      <defs>
                        <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="day" stroke="rgba(255,255,255,0.5)" />
                      <YAxis stroke="rgba(255,255,255,0.5)" />
                      <Tooltip contentStyle={{ background: 'rgba(0,0,0,0.8)', border: 'none' }} />
                      <Area type="monotone" dataKey="usage" stroke="#3B82F6" fillOpacity={1} fill="url(#colorUsage)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </motion.div>

                {/* Auth Types Pie Chart */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 }}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
                >
                  <h3 className="text-lg font-semibold mb-4">Auth Methods Distribution</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={chartData.authTypes}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {chartData.authTypes.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </motion.div>
              </div>

              {/* Quick Actions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
              >
                <QuickActionCard
                  icon={Package}
                  title="Buy Credits"
                  description="Purchase additional authentication credits"
                  onClick={() => router.push('/packages')}
                  color="from-blue-600/20 to-cyan-600/20"
                />
                <QuickActionCard
                  icon={FileText}
                  title="API Documentation"
                  description="View integration guides and examples"
                  onClick={() => router.push('/docs')}
                  color="from-purple-600/20 to-pink-600/20"
                />
                <QuickActionCard
                  icon={HelpCircle}
                  title="Support"
                  description="Get help from our support team"
                  onClick={() => router.push('/support')}
                  color="from-green-600/20 to-emerald-600/20"
                />
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6"
              >
                <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <motion.div
                      key={activity.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8 + index * 0.1 }}
                      className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${
                          activity.type === 'auth' ? 'bg-blue-500/20' :
                          activity.type === 'credit' ? 'bg-green-500/20' :
                          'bg-purple-500/20'
                        }`}>
                          {activity.type === 'auth' && <Shield className="w-4 h-4" />}
                          {activity.type === 'credit' && <CreditCard className="w-4 h-4" />}
                          {activity.type === 'settings' && <Settings className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="text-sm">{activity.description}</div>
                          <div className="text-xs text-white/60">{activity.time}</div>
                        </div>
                      </div>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        activity.status === 'success' ? 'bg-green-500/20 text-green-300' :
                        activity.status === 'added' ? 'bg-blue-500/20 text-blue-300' :
                        'bg-purple-500/20 text-purple-300'
                      }`}>
                        {activity.status}
                      </span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>

              {/* Features */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-4"
              >
                <FeatureHighlight
                  icon={Zap}
                  title="Lightning Fast"
                  description="Average response time under 200ms for all authentication requests"
                />
                <FeatureHighlight
                  icon={Shield}
                  title="Bank-Grade Security"
                  description="End-to-end encryption and compliance with industry standards"
                />
                <FeatureHighlight
                  icon={Globe}
                  title="Global Coverage"
                  description="Support for 150+ countries with local phone number validation"
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
