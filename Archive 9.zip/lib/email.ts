import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

interface SendEmailOptions {
  to: string;
  subject: string;
  text?: string;
  html?: string;
  from?: string;
}

/**
 * Sends an email using Resend
 * @returns Promise<boolean> - true if email was sent successfully, false otherwise
 */
export async function sendEmail({
  to,
  subject,
  text,
  html,
  from = process.env.EMAIL_FROM || 'noreply@truotp.com'
}: SendEmailOptions): Promise<boolean> {
  // Validate required fields
  if (!to || !subject) {
    console.error('Email sending failed: Missing required fields (to or subject)');
    return false;
  }

  if (!process.env.RESEND_API_KEY) {
    console.error('RESEND_API_KEY is not configured. Please add it to your environment variables.');
    return false;
  }

  try {
    console.log(`Sending email to: ${to}, subject: ${subject}`);
    
    const emailData = {
      from: `TruOTP <${from}>`,
      to: [to],
      subject,
      html: html || text || ' ',
      text: text || ' ',
      replyTo: process.env.EMAIL_REPLY_TO || from,
    };
    
    const { data, error } = await resend.emails.send(emailData);

    if (error) {
      console.error('Failed to send email:', error);
      return false;
    }

    console.log('Email sent successfully:', data);
    return true;

    return false;
  } catch (e) {
    console.error('Unexpected error in sendEmail:', e);
    return false;
  }
}

