import { UAParser } from 'ua-parser-js';

interface DeviceInfo {
  device?: string;
  browser?: string;
  os?: string;
}

export function parseUserAgent(userAgent: string): DeviceInfo {
  if (!userAgent || userAgent === 'unknown device') {
    return {};
  }

  const parser = new UAParser(userAgent);
  const result = parser.getResult();

  return {
    device: result.device.model || result.device.vendor || undefined,
    browser: result.browser.name ? 
      `${result.browser.name}${result.browser.version ? ' ' + result.browser.version.split('.')[0] : ''}` : 
      undefined,
    os: result.os.name ? 
      `${result.os.name}${result.os.version ? ' ' + result.os.version.split('.')[0] : ''}` : 
      undefined
  };
}
