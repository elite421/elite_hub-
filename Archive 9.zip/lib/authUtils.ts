import { query } from './db';

export interface UserRegistrationStatus {
  isRegistered: boolean;
  hasCompletedRegistration: boolean;
  email?: string | null;
  name?: string | null;
}

export async function checkUserRegistration(userId: number): Promise<UserRegistrationStatus> {
  try {
    const result = await query<{ email: string | null; name: string | null }>(
      `SELECT email, name FROM users WHERE id = $1 LIMIT 1`,
      [userId]
    );

    if (result.rows.length === 0) {
      return { isRegistered: false, hasCompletedRegistration: false };
    }

    const user = result.rows[0];
    const hasCompletedRegistration = Boolean(user.email && user.name);

    return {
      isRegistered: true,
      hasCompletedRegistration,
      email: user.email,
      name: user.name
    };
  } catch (error) {
    console.error('Error checking user registration status:', error);
    return { isRegistered: false, hasCompletedRegistration: false };
  }
}
