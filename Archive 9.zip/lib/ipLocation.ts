interface IpLocation {
  city?: string;
  region?: string;
  country?: string;
  timezone?: string;
}

export async function getLocationFromIp(ip: string): Promise<string> {
  if (!ip || ip === 'unknown IP') {
    return 'Unknown location';
  }

  // Skip localhost and private IPs
  if ([
    '127.0.0.1',
    '::1',
    '::ffff:127.0.0.1',
    '10.0.0.0/8',
    '172.16.0.0/12',
    '192.168.0.0/16'
  ].some(addr => ip.startsWith(addr))) {
    return 'Local network';
  }

  try {
    // Use ipinfo.io for IP geolocation (free tier available)
    const response = await fetch(`https://ipinfo.io/${ip}/json?token=${process.env.IPINFO_TOKEN || ''}`);
    if (!response.ok) throw new Error('Failed to fetch location');
    
    const data = await response.json();
    const { city, region, country, timezone } = data as IpLocation;
    
    const locationParts = [];
    if (city) locationParts.push(city);
    if (region && region !== city) locationParts.push(region);
    if (country) locationParts.push(country);
    if (timezone) locationParts.push(`(${timezone})`);
    
    return locationParts.length > 0 ? locationParts.join(', ') : 'Unknown location';
  } catch (error) {
    console.error('Error getting IP location:', error);
    return 'Location unknown';
  }
}
