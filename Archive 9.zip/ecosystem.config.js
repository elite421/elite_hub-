module.exports = {
  apps: [
    {
      name: 'nextjs-app',
      cwd: '/opt/myapp',
      script: 'node_modules/next/dist/bin/next',
      args: 'start -p 3000',
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        NODE_OPTIONS: '--max-old-space-size=1024',
        // Add other environment variables here
      },
      error_file: '/var/log/myapp/nextjs-error.log',
      out_file: '/var/log/myapp/nextjs-out.log',
      merge_logs: true,
      time: true,
      instances: 'max',
      exec_mode: 'cluster',
      max_memory_restart: '1G',
    },
    {
      name: 'whatsapp-bot',
      cwd: '/opt/myapp',
      script: 'cursor/bot.js',
      env_production: {
        NODE_ENV: 'production',
        // Add bot-specific environment variables here
      },
      error_file: '/var/log/myapp/bot-error.log',
      out_file: '/var/log/myapp/bot-out.log',
      merge_logs: true,
      time: true,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
    },
  ],
};
