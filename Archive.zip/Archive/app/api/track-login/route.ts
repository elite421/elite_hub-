import { NextRequest, NextResponse } from 'next/server';
import { requireUser } from '@/lib/authHelpers';
import { trackActiveSession } from '@/lib/sessionTracker';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const { user } = await requireUser();
    await trackActiveSession(req, user.id);
    return NextResponse.json({ success: true });
  } catch (e: any) {
    // If the session isn't ready yet, don't fail the login flow; just return success.
    if (e instanceof Response) {
      const status = (e as Response).status;
      if (status === 401 || status === 403) {
        return NextResponse.json({ success: true, skipped: true });
      }
      return e;
    }
    return NextResponse.json({ success: false, message: e?.message || 'Failed to track login' }, { status: 500 });
  }
}
