"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type QrJson = { ok: boolean; dataUrl?: string; ts?: string; message?: string };

export default function BotQrPage() {
  const [img, setImg] = useState<string>("");
  const [ts, setTs] = useState<string>("");
  const [err, setErr] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const timer = useRef<NodeJS.Timeout | null>(null);

  async function fetchQR() {
    try {
      setLoading(true);
      setErr("");
      const res = await fetch(`/api/public/bot/qr-json?${Date.now()}`, { cache: "no-store" });
      if (!res.ok) {
        setImg("");
        setTs("");
        setErr("QR not available yet");
        return;
      }
      const data: QrJson = await res.json();
      if (data && data.ok && data.dataUrl) {
        setImg(data.dataUrl);
        setTs(data.ts || "");
      } else {
        setImg("");
        setTs("");
        setErr(data?.message || "QR not available yet");
      }
    } catch (e: any) {
      setImg("");
      setTs("");
      setErr("Unable to reach bot QR endpoint");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchQR();
    timer.current = setInterval(fetchQR, 4000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, []);

  const timeText = useMemo(() => (ts ? new Date(ts).toLocaleString() : ""), [ts]);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#0b0b0b", color: "#eaeaea", padding: 24 }}>
      <div style={{ textAlign: "center", maxWidth: 520 }}>
        <h1 style={{ fontSize: 28, marginBottom: 16 }}>Scan to link WhatsApp</h1>
        {img ? (
          <img src={img} alt="WhatsApp QR" width={320} height={320} style={{ imageRendering: "pixelated", borderRadius: 8 }} />
        ) : (
          <div style={{ width: 320, height: 320, display: "flex", alignItems: "center", justifyContent: "center", border: "1px dashed #444", borderRadius: 8, margin: "0 auto" }}>
            <span style={{ color: "#aaa" }}>{loading ? "Loading..." : (err || "Waiting for QR...")}</span>
          </div>
        )}
        <div style={{ marginTop: 12, display: "flex", gap: 12, justifyContent: "center" }}>
          <button onClick={fetchQR} disabled={loading} style={{ background: "#111827", color: "#e5e7eb", border: "1px solid #374151", padding: "8px 14px", borderRadius: 8, cursor: "pointer" }}>
            {loading ? "Refreshing..." : "Refresh"}
          </button>
        </div>
        {timeText ? <p style={{ marginTop: 10, color: "#9ca3af" }}>Generated: {timeText}</p> : null}
        <p style={{ marginTop: 12, color: "#9ca3af" }}>Keep this page open. QR rotates periodically. Once linked, QR disappears.</p>
      </div>
    </div>
  );
}
